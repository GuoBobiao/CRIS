% Run the public CRIS regression test suite.

testDirectory = fileparts(mfilename("fullpath"));
repositoryRoot = fileparts(testDirectory);
addpath(repositoryRoot);
projectRoot = setup_cris();
addpath(fullfile(projectRoot, "tests"));
results = runtests(fullfile(projectRoot, "tests", ...
    "test_cris_reproducibility.m"));
disp(table(results));
assertSuccess(results);
