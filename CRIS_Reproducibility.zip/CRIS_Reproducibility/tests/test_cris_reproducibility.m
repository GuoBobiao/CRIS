function tests = test_cris_reproducibility
% Define configuration, determinism, and supplied-artifact regression tests.

tests = functiontests(localfunctions);
end

function setupOnce(testCase)
projectRoot = fileparts(fileparts(mfilename("fullpath")));
setup_cris();
testCase.TestData.cfg = cris_default_config(string(projectRoot));
end

function testCatalogSizes(testCase)
verifyEqual(testCase, height(cris_table_iii_catalog()), 17);
verifyEqual(testCase, height(cris_fig8_catalog()), 24);
end

function testVariantParameterLengths(testCase)
for name = ["PCET", "PCT", "PST"]
    variant = cris_variant_config(name);
    verifyEqual(testCase, numel(variant.messageSteps), 256);
    verifyTrue(testCase, all(ismember(variant.messageSteps, [11, 12])));
end
end

function testNoiseAttackIsDeterministic(testCase)
image = uint8(repmat(0:255, 256, 1));
first = cris_apply_fig8_attack(image, "gaussian", 0.0005, [256, 256], 7);
second = cris_apply_fig8_attack(image, "gaussian", 0.0005, [256, 256], 7);
verifyEqual(testCase, first, second);
end

function testSuppliedSenderArtifactsPixelExactly(testCase)
cfg = testCase.TestData.cfg;
assumeTrue(testCase, isfolder(cfg.dataRoot), ...
    "The optional supplied dataset is unavailable.");

imageDirectories = ["Image", "Image", "image"];
for variantIndex = 1:numel(cfg.variants)
    variant = cris_variant_config(cfg.variants(variantIndex));
    cover = imread(fullfile(cfg.dataRoot, "Cover_Image", "anhinga.png"));
    secret = cris_load_secret(fullfile(cfg.dataRoot, variant.dataDirectory, ...
        "secret", "1.xlsx"), cfg.messageLength);
    plans = cris_prepare_variant_plans(cfg, variant, "embed");
    actual = cris_embed_image(cover, secret, cfg, variant, plans);
    expectedStego = imread(fullfile(cfg.dataRoot, variant.dataDirectory, ...
        "Stego_Image", "anhinga.png"));
    expectedTrustworthy = imread(fullfile(cfg.dataRoot, ...
        variant.dataDirectory, imageDirectories(variantIndex), ...
        "Trustworthy_Image", "anhinga.png"));
    verifyEqual(testCase, actual.stegoImage, expectedStego);
    verifyEqual(testCase, actual.trustworthyImage, expectedTrustworthy);
    clear plans;
end
end
