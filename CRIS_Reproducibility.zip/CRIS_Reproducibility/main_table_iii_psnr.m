% Compute the Table III PSNR row from the supplied image folders.

projectRoot = setup_cris();
cfg = cris_default_config(projectRoot);

% Set to a positive integer for a quick smoke test; use Inf for all images.
cfg.execution.maxImages = Inf;

% Refresh the quality artifacts when this entry point is rerun.
cfg.execution.overwrite = true;

result = cris_compute_table_iii_psnr(cfg);
metricVariables = string(result.tableIII.Properties.VariableNames(2:end));
displayTableIII = cris_format_metric_columns( ...
    result.tableIII, metricVariables, 4);
disp(displayTableIII);
