function result = cris_reproduce_fig8(cfg)
% Apply the Fig. 8 attacks and evaluate robustness and credibility.

coverFiles = cris_list_images(fullfile(cfg.dataRoot, "Cover_Image"));
imageCount = min(numel(coverFiles), cfg.execution.maxImages);
coverFiles = coverFiles(1:imageCount);
catalog = cris_fig8_catalog();
outputDirectory = fullfile(cfg.resultsRoot, "fig8");
cris_prepare_output_directory(outputDirectory, cfg.execution.overwrite);

summary = table();
perImage = table();

for variantIndex = 1:numel(cfg.variants)
    variant = cris_variant_config(cfg.variants(variantIndex));
    fprintf("Fig. 8: preparing %s-CRIS plans.\n", variant.name);
    plans = cris_prepare_variant_plans(cfg, variant, "extract");
    variantRoot = fullfile(cfg.dataRoot, variant.dataDirectory);
    trustworthyRoot = fullfile(variantRoot, variant.imageDirectory, ...
        "Trustworthy_Image");
    trustworthyFiles = cris_list_images(trustworthyRoot);

    for attackIndex = 1:height(catalog)
        robustness = zeros(imageCount, 1);
        credibility = zeros(imageCount, 1);
        inputFile = strings(imageCount, 1);

        for imageIndex = 1:imageCount
            inputFile(imageIndex) = cris_find_matching_image( ...
                trustworthyFiles, coverFiles(imageIndex).name);
            trustworthy = imread(inputFile(imageIndex));
            randomSeed = cfg.execution.randomSeed + ...
                variantIndex * 100000 + attackIndex * 1000 + imageIndex;
            attacked = cris_apply_fig8_attack(trustworthy, ...
                catalog.Type(attackIndex), catalog.Parameter(attackIndex), ...
                cfg.imageSize, randomSeed);
            extracted = cris_extract_image(attacked, cfg, variant, plans);
            secret = cris_load_secret(fullfile(variantRoot, "secret", ...
                compose("%d.xlsx", imageIndex)), cfg.messageLength);
            robustness(imageIndex) = cris_bit_accuracy(secret, extracted.message);
            credibility(imageIndex) = extracted.credibility;
        end

        difference = credibility - robustness;
        averageRobustness = mean(robustness);
        averageCredibility = mean(credibility);
        summaryRow = table(variant.name, catalog.Type(attackIndex), ...
            catalog.Parameter(attackIndex), catalog.Name(attackIndex), ...
            averageRobustness, averageCredibility, ...
            averageCredibility - averageRobustness, imageCount, ...
            'VariableNames', {'Variant', 'AttackType', 'Parameter', ...
            'AttackName', 'Robustness', 'Credibility', 'Difference', ...
            'ImageCount'});
        summary = [summary; summaryRow]; %#ok<AGROW>

        imageRows = table(repmat(variant.name, imageCount, 1), ...
            repmat(catalog.Type(attackIndex), imageCount, 1), ...
            repmat(catalog.Parameter(attackIndex), imageCount, 1), ...
            repmat(catalog.Name(attackIndex), imageCount, 1), ...
            (1:imageCount).', string({coverFiles.name}).', inputFile, ...
            robustness, credibility, difference, 'VariableNames', ...
            {'Variant', 'AttackType', 'Parameter', 'AttackName', ...
            'ImageIndex', 'CoverName', 'InputFile', 'Robustness', ...
            'Credibility', 'Difference'});
        perImage = [perImage; imageRows]; %#ok<AGROW>
        fprintf("  %s %s: robustness %.4f, credibility %.4f\n", ...
            variant.name, catalog.Name(attackIndex), ...
            averageRobustness, averageCredibility);
    end
    clear plans;
end

summaryFullPrecision = summary;
summary = cris_round_metric_triplet(summary, ...
    "Robustness", "Credibility", "Difference", 4);

summaryCsv = fullfile(outputDirectory, "Figure_8_data.csv");
summaryXlsx = fullfile(outputDirectory, "Figure_8_data.xlsx");
perImageCsv = fullfile(outputDirectory, "Figure_8_per_image.csv");
summaryForExport = cris_format_metric_columns(summary, ...
    ["Robustness", "Credibility", "Difference"], 4);
writetable(summaryForExport, summaryCsv);
writetable(summaryForExport, summaryXlsx, "Sheet", "Summary");
writetable(perImage, perImageCsv);
writetable(perImage, summaryXlsx, "Sheet", "PerImage");
save(fullfile(outputDirectory, "Figure_8_data.mat"), ...
    "summary", "summaryFullPrecision", "perImage", "catalog");
cris_save_run_config(cfg, fullfile(outputDirectory, "run_config.mat"));
cris_plot_fig8(summary, outputDirectory, cfg.variants);

result.summary = summary;
result.summaryFullPrecision = summaryFullPrecision;
result.perImage = perImage;
result.outputDirectory = outputDirectory;
end
