function result = cris_run_extraction_batch(cfg)
% Batch-extract secret images and compare them with saved random secrets.

validateBatchConfiguration(cfg);
variant = cris_variant_config(cfg.variant);
receivedFiles = cris_list_images(cfg.batch.receivedImageDirectory);
secretFiles = cris_list_images(cfg.batch.secretImageDirectory);
imageCount = min(numel(receivedFiles), cfg.execution.maxImages);
receivedFiles = receivedFiles(1:imageCount);
stems = validateUniqueStems(receivedFiles, ...
    cfg.batch.receivedImageDirectory);

outputDirectory = string(cfg.batch.receiverOutputDirectory);
if strlength(outputDirectory) == 0
    outputDirectory = fullfile( ...
        cfg.resultsRoot, "batch", variant.name, "receiver");
end
cris_prepare_output_directory(outputDirectory, cfg.execution.overwrite);

extractedImageDirectory = fullfile( ...
    outputDirectory, "extracted_secret_images");
extractedMessageDirectory = fullfile( ...
    outputDirectory, "extracted_messages");
credibilityDirectory = fullfile(outputDirectory, "pair_credibility");
metadataDirectory = fullfile(outputDirectory, "receiver_metadata");
ensureDirectories([extractedImageDirectory, extractedMessageDirectory, ...
    credibilityDirectory, metadataDirectory]);

fprintf("Batch extraction: preparing %s-CRIS plans.\n", variant.name);
plans = cris_prepare_variant_plans(cfg, variant, "extract");
receivedPaths = strings(imageCount, 1);
secretPaths = strings(imageCount, 1);
extractedImagePaths = strings(imageCount, 1);
extractedMessagePaths = strings(imageCount, 1);
messageAccuracy = zeros(imageCount, 1);
bitErrors = zeros(imageCount, 1);
credibility = zeros(imageCount, 1);
accepted = false(imageCount, 1);
extractionTimeSeconds = zeros(imageCount, 1);
robustnessExtractionTimeSeconds = zeros(imageCount, 1);
credibilityExtractionTimeSeconds = zeros(imageCount, 1);

for imageIndex = 1:imageCount
    receivedPaths(imageIndex) = fullfile( ...
        receivedFiles(imageIndex).folder, receivedFiles(imageIndex).name);
    secretPaths(imageIndex) = cris_find_matching_image( ...
        secretFiles, receivedFiles(imageIndex).name);
    secretMessage = loadSecretImage( ...
        secretPaths(imageIndex), cfg.batch.secretImageSize);
    receivedImage = imread(receivedPaths(imageIndex));
    extractionTimer = tic;
    extracted = cris_extract_image( ...
        receivedImage, cfg, variant, plans);
    extractionTimeSeconds(imageIndex) = toc(extractionTimer);
    robustnessExtractionTimeSeconds(imageIndex) = ...
        extracted.robustnessExtractionTimeSeconds;
    credibilityExtractionTimeSeconds(imageIndex) = ...
        extracted.credibilityExtractionTimeSeconds;
    extractedMessage = double(extracted.message(:).' >= 0.5);

    bitErrors(imageIndex) = sum(extractedMessage ~= secretMessage);
    messageAccuracy(imageIndex) = 1 - ...
        bitErrors(imageIndex) / cfg.messageLength;
    credibility(imageIndex) = extracted.credibility;
    accepted(imageIndex) = extracted.isAccepted;

    outputName = stems(imageIndex) + ".png";
    extractedImagePaths(imageIndex) = fullfile( ...
        extractedImageDirectory, outputName);
    extractedMessagePaths(imageIndex) = fullfile( ...
        extractedMessageDirectory, stems(imageIndex) + ".csv");
    extractedSecretImage = reshape( ...
        uint8(extractedMessage), cfg.batch.secretImageSize);
    imwrite(uint8(double(extractedSecretImage) * 255), ...
        extractedImagePaths(imageIndex));
    writematrix(extractedMessage, extractedMessagePaths(imageIndex));
    writematrix(extracted.pairCredibility, fullfile( ...
        credibilityDirectory, stems(imageIndex) + ".csv"));
    save(fullfile(metadataDirectory, stems(imageIndex) + ".mat"), ...
        "extracted", "variant");

    if shouldReportProgress(imageIndex, imageCount, cfg.execution.progressEvery)
        fprintf("  Extracted %d/%d images; accuracy %.4f.\n", ...
            imageIndex, imageCount, messageAccuracy(imageIndex));
    end
end

bitErrorRate = bitErrors / cfg.messageLength;
perImage = table((1:imageCount).', string({receivedFiles.name}).', ...
    receivedPaths, secretPaths, extractedImagePaths, ...
    extractedMessagePaths, messageAccuracy, bitErrors, bitErrorRate, ...
    credibility, accepted, extractionTimeSeconds, ...
    robustnessExtractionTimeSeconds, credibilityExtractionTimeSeconds, ...
    'VariableNames', {'ImageIndex', 'ReceivedName', 'ReceivedFile', ...
    'SecretImageFile', 'ExtractedSecretImageFile', ...
    'ExtractedMessageFile', 'MessageAccuracy', 'BitErrors', ...
    'BitErrorRate', 'Credibility', 'Accepted', ...
    'ExtractionTimeSeconds', 'RobustnessExtractionTimeSeconds', ...
    'CredibilityExtractionTimeSeconds'});
overallAccuracy = 1 - sum(bitErrors) / (imageCount * cfg.messageLength);
summary = table(variant.name, imageCount, mean(messageAccuracy), ...
    overallAccuracy, mean(bitErrorRate), mean(credibility), ...
    mean(accepted), mean(extractionTimeSeconds), ...
    mean(robustnessExtractionTimeSeconds), ...
    mean(credibilityExtractionTimeSeconds), string(outputDirectory), ...
    'VariableNames', {'Variant', 'ImageCount', 'MeanMessageAccuracy', ...
    'OverallMessageAccuracy', 'MeanBitErrorRate', 'MeanCredibility', ...
    'AcceptanceRate', 'MeanExtractionTimeSeconds', ...
    'MeanRobustnessExtractionTimeSeconds', ...
    'MeanCredibilityExtractionTimeSeconds', 'OutputDirectory'});

perImageCsv = fullfile(outputDirectory, "batch_extraction_per_image.csv");
summaryCsv = fullfile(outputDirectory, "batch_extraction_summary.csv");
workbook = fullfile(outputDirectory, "batch_extraction_results.xlsx");
summaryForExport = cris_format_metric_columns(summary, ...
    ["MeanMessageAccuracy", "OverallMessageAccuracy", ...
     "MeanBitErrorRate", "MeanCredibility", "AcceptanceRate", ...
     "MeanExtractionTimeSeconds", "MeanRobustnessExtractionTimeSeconds", ...
     "MeanCredibilityExtractionTimeSeconds"], 4);
writetable(perImage, perImageCsv);
writetable(summaryForExport, summaryCsv);
writetable(summaryForExport, workbook, "Sheet", "Summary");
writetable(perImage, workbook, "Sheet", "PerImage");
cris_save_run_config(cfg, fullfile(outputDirectory, "run_config.mat"));
save(fullfile(outputDirectory, "batch_extraction_results.mat"), ...
    "summary", "perImage", "variant");

result.summary = summary;
result.perImage = perImage;
result.outputDirectory = outputDirectory;
result.perImageFile = perImageCsv;
result.summaryFile = summaryCsv;
end

function validateBatchConfiguration(cfg)
validateattributes(cfg.execution.maxImages, {'numeric'}, ...
    {'scalar', 'positive'});
validateattributes(cfg.batch.secretImageSize, {'numeric'}, ...
    {'row', 'numel', 2, 'integer', 'positive'});
if prod(cfg.batch.secretImageSize) ~= cfg.messageLength
    error("CRIS:InvalidSecretImageSize", ...
        "Secret image dimensions must contain exactly %d pixels.", ...
        cfg.messageLength);
end
if strlength(string(cfg.batch.receivedImageDirectory)) == 0
    error("CRIS:MissingReceivedDirectory", ...
        "Set cfg.batch.receivedImageDirectory before batch extraction.");
end
if strlength(string(cfg.batch.secretImageDirectory)) == 0
    error("CRIS:MissingSecretDirectory", ...
        "Set cfg.batch.secretImageDirectory before batch extraction.");
end
end

function message = loadSecretImage(path, expectedSize)
secretImage = imread(path);
if ndims(secretImage) == 3
    secretImage = rgb2gray(secretImage);
end
if ~isequal(size(secretImage), expectedSize)
    error("CRIS:InvalidSecretImageSize", ...
        "Secret image %s must have size %dx%d.", ...
        path, expectedSize(1), expectedSize(2));
end
message = double(secretImage(:).' >= 128);
end

function stems = validateUniqueStems(files, directory)
stems = strings(numel(files), 1);
for index = 1:numel(files)
    [~, stems(index)] = fileparts(files(index).name);
end
if numel(unique(lower(stems))) ~= numel(stems)
    error("CRIS:DuplicateImageStem", ...
        "Image filenames in %s must have unique stems.", directory);
end
end

function ensureDirectories(directories)
for directory = directories
    if ~isfolder(directory)
        mkdir(directory);
    end
end
end

function report = shouldReportProgress(index, count, interval)
report = index == count || (interval > 0 && mod(index, interval) == 0);
end
