function attacked = cris_apply_fig8_attack(image, attackType, parameter, ...
    targetSize, randomSeed)
% Apply one Fig. 8 degradation using the original experiment definitions.

image = cris_normalize_input_image(image, targetSize);
attackType = string(attackType);

switch attackType
    case "gaussian"
        rng(randomSeed, "twister");
        attacked = imnoise(image, "gaussian", 0, parameter);
    case "saltpepper"
        rng(randomSeed, "twister");
        attacked = imnoise(image, "salt & pepper", parameter);
    case "cropping"
        attacked = image;
        rowCount = size(attacked, 1);
        columnCount = size(attacked, 2);
        cropRows = round(rowCount * parameter);
        cropColumns = round(columnCount * parameter);
        rowBegin = max(round((rowCount - cropRows) / 2), 1);
        rowEnd = min(rowBegin + cropRows, rowCount);
        columnBegin = max(round((columnCount - cropColumns) / 2), 1);
        columnEnd = min(columnBegin + cropColumns, columnCount);
        attacked(rowBegin:rowEnd, columnBegin:columnEnd, :) = 0;
    case "rotation"
        attacked = imrotate(image, parameter, "nearest", "crop");
    otherwise
        error("CRIS:UnknownFig8Attack", ...
            "Unknown Fig. 8 attack type: %s", attackType);
end

attacked = imresize(attacked, targetSize);
end

