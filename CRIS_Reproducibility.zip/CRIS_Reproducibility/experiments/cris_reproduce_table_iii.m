function result = cris_reproduce_table_iii(cfg)
% Reproduce the principal table from the supplied experiment data.

validateattributes(cfg.execution.maxImages, {'numeric'}, ...
    {'scalar', 'positive'});
coverFiles = cris_list_images(fullfile(cfg.dataRoot, "Cover_Image"));
imageCount = min(numel(coverFiles), cfg.execution.maxImages);
coverFiles = coverFiles(1:imageCount);
catalog = cris_table_iii_catalog();

outputDirectory = fullfile(cfg.resultsRoot, "table_iii");
cris_prepare_output_directory(outputDirectory, cfg.execution.overwrite);

summary = initializeSummary(catalog, cfg.variants);
allPerImage = table();
allQualityPerImage = table();

for variantIndex = 1:numel(cfg.variants)
    variant = cris_variant_config(cfg.variants(variantIndex));
    fprintf("Principal table: preparing %s-CRIS plans.\n", variant.name);
    plans = cris_prepare_variant_plans(cfg, variant, "extract");
    variantRoot = fullfile(cfg.dataRoot, variant.dataDirectory);
    imageRoot = fullfile(variantRoot, variant.imageDirectory);

    [quality, qualityPerImage] = evaluateQuality( ...
        cfg, variant, coverFiles, variantRoot, imageRoot, outputDirectory);
    allQualityPerImage = [allQualityPerImage; qualityPerImage]; %#ok<AGROW>
    summary = assignQuality(summary, variant.name, quality);

    variantPerImage = table();
    attackRobustness = zeros(height(catalog), 1);
    attackCredibility = zeros(height(catalog), 1);

    for attackIndex = 1:height(catalog)
        attackDirectory = cris_resolve_attack_directory( ...
            imageRoot, catalog.FolderAliases{attackIndex});
        attackedFiles = cris_list_images(attackDirectory);
        [robustness, credibility, perImage] = evaluateAttackFolder( ...
            cfg, variant, plans, coverFiles, attackedFiles, ...
            catalog.Number(attackIndex), catalog.Label(attackIndex), ...
            variantRoot);
        attackRobustness(attackIndex) = robustness;
        attackCredibility(attackIndex) = credibility;
        variantPerImage = [variantPerImage; perImage]; %#ok<AGROW>
        fprintf("  %s NO.%d: robustness %.4f, credibility %.4f\n", ...
            variant.name, catalog.Number(attackIndex), robustness, credibility);
    end

    summary = assignAttacks(summary, variant.name, ...
        attackRobustness, attackCredibility);
    allPerImage = [allPerImage; variantPerImage]; %#ok<AGROW>
    clear plans;
end

summaryFullPrecision = summary;
for variantName = cfg.variants
    prefix = char(variantName);
    summary = cris_round_metric_triplet(summary, ...
        string(sprintf('%s_RobustnessOrStego', prefix)), ...
        string(sprintf('%s_CredibilityOrTrustworthy', prefix)), ...
        string(sprintf('%s_Difference', prefix)), 4);
end

summaryCsv = fullfile(outputDirectory, "Table_III_reproduced.csv");
summaryXlsx = fullfile(outputDirectory, "Table_III_reproduced.xlsx");
perImageCsv = fullfile(outputDirectory, "Table_III_per_image.csv");
qualityCsv = fullfile(outputDirectory, "Table_III_quality_per_image.csv");
metricVariables = string(summary.Properties.VariableNames(3:end));
summaryForExport = cris_format_metric_columns(summary, metricVariables, 4);
writetable(summaryForExport, summaryCsv);
writetable(summaryForExport, summaryXlsx, "Sheet", "Summary");
writetable(allPerImage, perImageCsv);
writetable(allPerImage, summaryXlsx, "Sheet", "PerImageAttacks");
writetable(allQualityPerImage, qualityCsv);
writetable(allQualityPerImage, summaryXlsx, "Sheet", "PerImageQuality");
comparison = table();
if imageCount == 60
    comparison = cris_compare_table_iii_to_paper(summary, catalog);
    comparisonForExport = cris_format_metric_columns(comparison, ...
        ["Reproduced", "Published", "AbsoluteError"], 4);
    comparisonCsv = fullfile(outputDirectory, ...
        "Table_III_paper_comparison.csv");
    writetable(comparisonForExport, comparisonCsv);
    writetable(comparisonForExport, summaryXlsx, "Sheet", "PaperComparison");
end
cris_save_run_config(cfg, fullfile(outputDirectory, "run_config.mat"));
save(fullfile(outputDirectory, "Table_III_reproduced.mat"), ...
    "summary", "summaryFullPrecision", "allPerImage", ...
    "allQualityPerImage", "catalog", "comparison");

result.summary = summary;
result.summaryFullPrecision = summaryFullPrecision;
result.perImage = allPerImage;
result.qualityPerImage = allQualityPerImage;
result.paperComparison = comparison;
result.outputDirectory = outputDirectory;
end

function summary = initializeSummary(catalog, variants)
caseLabel = ["Quality"; "Quality"; repmat("", height(catalog), 1); ""];
metric = ["PSNR"; "LPIPS"; catalog.Label; "Average"];
summary = table(caseLabel, metric, 'VariableNames', ...
    {'Case', 'MetricsAndDegradations'});

for variantName = variants
    prefix = char(variantName);
    summary.(sprintf('%s_RobustnessOrStego', prefix)) = nan(height(summary), 1);
    summary.(sprintf('%s_CredibilityOrTrustworthy', prefix)) = nan(height(summary), 1);
    summary.(sprintf('%s_Difference', prefix)) = nan(height(summary), 1);
end

summary.Case(3:9) = "I";
summary.Case(10:15) = "II";
summary.Case(16:19) = "III";
summary.Case(end) = "Average";
end

function summary = assignQuality(summary, variantName, quality)
prefix = char(variantName);
left = [quality.StegoPSNR; quality.StegoLPIPS];
right = [quality.TrustworthyPSNR; quality.TrustworthyLPIPS];
leftName = sprintf('%s_RobustnessOrStego', prefix);
rightName = sprintf('%s_CredibilityOrTrustworthy', prefix);
differenceName = sprintf('%s_Difference', prefix);
summary{1:2, leftName} = left;
summary{1:2, rightName} = right;
summary{1:2, differenceName} = right - left;
end

function summary = assignAttacks(summary, variantName, robustness, credibility)
prefix = char(variantName);
rows = 3:(2 + numel(robustness));
leftName = sprintf('%s_RobustnessOrStego', prefix);
rightName = sprintf('%s_CredibilityOrTrustworthy', prefix);
differenceName = sprintf('%s_Difference', prefix);
summary{rows, leftName} = robustness;
summary{rows, rightName} = credibility;
summary{rows, differenceName} = credibility - robustness;
summary{height(summary), leftName} = mean(robustness);
summary{height(summary), rightName} = mean(credibility);
summary{height(summary), differenceName} = mean(credibility - robustness);
end

function [quality, perImage] = evaluateQuality( ...
    cfg, variant, coverFiles, variantRoot, imageRoot, outputDirectory)
stegoFiles = cris_list_images(fullfile(variantRoot, "Stego_Image"));
trustworthyFiles = cris_list_images(fullfile(imageRoot, "Trustworthy_Image"));
count = numel(coverFiles);
stegoPsnr = zeros(count, 1);
trustworthyPsnr = zeros(count, 1);
coverPaths = strings(count, 1);
stegoPaths = strings(count, 1);
trustworthyPaths = strings(count, 1);

for imageIndex = 1:count
    coverPaths(imageIndex) = fullfile( ...
        coverFiles(imageIndex).folder, coverFiles(imageIndex).name);
    stegoPaths(imageIndex) = cris_find_matching_image( ...
        stegoFiles, coverFiles(imageIndex).name);
    trustworthyPaths(imageIndex) = cris_find_matching_image( ...
        trustworthyFiles, coverFiles(imageIndex).name);
    cover = cris_normalize_input_image(imread(coverPaths(imageIndex)), cfg.imageSize);
    stego = cris_normalize_input_image(imread(stegoPaths(imageIndex)), cfg.imageSize);
    trustworthy = cris_normalize_input_image( ...
        imread(trustworthyPaths(imageIndex)), cfg.imageSize);
    stegoPsnr(imageIndex) = psnr(stego, cover);
    trustworthyPsnr(imageIndex) = psnr(trustworthy, cover);
end

stegoLpips = nan(count, 1);
trustworthyLpips = nan(count, 1);
if cfg.evaluation.lpips.enabled
    pairManifest = table( ...
        [repmat("Stego", count, 1); repmat("Trustworthy", count, 1)], ...
        [coverPaths; coverPaths], [stegoPaths; trustworthyPaths], ...
        'VariableNames', {'Kind', 'Reference', 'Candidate'});
    lpipsManifest = fullfile(outputDirectory, ...
        "lpips_pairs_" + lower(variant.name) + ".csv");
    lpipsOutput = fullfile(outputDirectory, ...
        "lpips_scores_" + lower(variant.name) + ".csv");
    writetable(pairManifest, lpipsManifest);
    scores = cris_compute_lpips_batch(cfg, lpipsManifest, lpipsOutput);
    if numel(scores) == 2 * count
        stegoLpips = scores(1:count);
        trustworthyLpips = scores((count + 1):end);
    end
end

quality.StegoPSNR = mean(stegoPsnr);
quality.TrustworthyPSNR = mean(trustworthyPsnr);
quality.StegoLPIPS = mean(stegoLpips, "omitnan");
quality.TrustworthyLPIPS = mean(trustworthyLpips, "omitnan");
if all(isnan(stegoLpips))
    quality.StegoLPIPS = NaN;
    quality.TrustworthyLPIPS = NaN;
end

perImage = table(repmat(variant.name, count, 1), (1:count).', ...
    string({coverFiles.name}).', coverPaths, stegoPaths, trustworthyPaths, ...
    stegoPsnr, trustworthyPsnr, stegoLpips, trustworthyLpips, ...
    'VariableNames', {'Variant', 'ImageIndex', 'CoverName', 'CoverFile', ...
    'StegoFile', 'TrustworthyFile', 'StegoPSNR', 'TrustworthyPSNR', ...
    'StegoLPIPS', 'TrustworthyLPIPS'});
end

function [averageRobustness, averageCredibility, perImage] = ...
    evaluateAttackFolder(cfg, variant, plans, coverFiles, attackedFiles, ...
    attackNumber, attackLabel, variantRoot)
count = numel(coverFiles);
robustness = zeros(count, 1);
credibility = zeros(count, 1);
difference = zeros(count, 1);
inputFile = strings(count, 1);

for imageIndex = 1:count
    inputFile(imageIndex) = cris_find_matching_image( ...
        attackedFiles, coverFiles(imageIndex).name);
    received = imread(inputFile(imageIndex));
    extracted = cris_extract_image(received, cfg, variant, plans);
    secretPath = fullfile(variantRoot, "secret", ...
        compose("%d.xlsx", imageIndex));
    secret = cris_load_secret(secretPath, cfg.messageLength);
    robustness(imageIndex) = cris_bit_accuracy(secret, extracted.message);
    credibility(imageIndex) = extracted.credibility;
    difference(imageIndex) = credibility(imageIndex) - robustness(imageIndex);
end

averageRobustness = mean(robustness);
averageCredibility = mean(credibility);
perImage = table(repmat(variant.name, count, 1), ...
    repmat(attackNumber, count, 1), repmat(attackLabel, count, 1), ...
    (1:count).', string({coverFiles.name}).', inputFile, ...
    robustness, credibility, difference, 'VariableNames', ...
    {'Variant', 'AttackNumber', 'Attack', 'ImageIndex', 'CoverName', ...
    'InputFile', 'Robustness', 'Credibility', 'Difference'});
end
