function cris_plot_fig8(summary, outputDirectory, variants)
% Render a three-panel robustness and credibility plot from Fig. 8 data.

attackTypes = ["gaussian", "saltpepper", "cropping", "rotation"];
colors = [0.00 0.45 0.74; 0.85 0.33 0.10; 0.47 0.67 0.19; 0.64 0.08 0.18];
figureHandle = figure("Visible", "off", "Color", "white", ...
    "Position", [100, 100, 1500, 480]);
layout = tiledlayout(1, 3, "TileSpacing", "compact", "Padding", "compact");
firstAxes = gobjects(1);

for variantIndex = 1:numel(variants)
    axesHandle = nexttile(layout);
    if variantIndex == 1
        firstAxes = axesHandle;
    end
    hold(axesHandle, "on");
    variantRows = summary(summary.Variant == variants(variantIndex), :);
    for typeIndex = 1:numel(attackTypes)
        rows = variantRows(variantRows.AttackType == attackTypes(typeIndex), :);
        x = 1:height(rows);
        plot(axesHandle, x, rows.Robustness, "-o", ...
            "Color", colors(typeIndex, :), "LineWidth", 1.2, ...
            "MarkerSize", 4, "DisplayName", ...
            titleCase(attackTypes(typeIndex)) + " (Robustness)");
        plot(axesHandle, x, rows.Credibility, "--s", ...
            "Color", colors(typeIndex, :), "LineWidth", 1.2, ...
            "MarkerSize", 4, "DisplayName", ...
            titleCase(attackTypes(typeIndex)) + " (Credibility)");
    end
    ylim(axesHandle, [0, 1]);
    xlim(axesHandle, [1, 6]);
    grid(axesHandle, "on");
    axesHandle.FontSize = 8;
    xlabel(axesHandle, "Degradation level index", "FontSize", 9);
    ylabel(axesHandle, "Robustness / Credibility", "FontSize", 9);
    title(axesHandle, "(" + char(96 + variantIndex) + ") " + ...
        variants(variantIndex) + "-CRIS", "FontSize", 11);
end

legend(firstAxes, "Location", "southwest", "FontSize", 6, ...
    "NumColumns", 2);

exportgraphics(figureHandle, fullfile(outputDirectory, ...
    "Figure_8_reproduced.png"), "Resolution", 300);
savefig(figureHandle, fullfile(outputDirectory, "Figure_8_reproduced.fig"));
close(figureHandle);
end

function label = titleCase(value)
switch value
    case "gaussian"
        label = "Gaussian";
    case "saltpepper"
        label = "Salt-and-pepper";
    case "cropping"
        label = "Cropping";
    case "rotation"
        label = "Rotation";
end
end
