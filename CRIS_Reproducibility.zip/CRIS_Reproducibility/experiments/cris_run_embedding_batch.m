function result = cris_run_embedding_batch(cfg)
% Batch-embed one saved random binary secret image per cover image.

validateBatchConfiguration(cfg);
variant = cris_variant_config(cfg.variant);
coverFiles = cris_list_images(cfg.batch.coverDirectory);
imageCount = min(numel(coverFiles), cfg.execution.maxImages);
coverFiles = coverFiles(1:imageCount);
stems = validateUniqueStems(coverFiles, cfg.batch.coverDirectory);

outputDirectory = string(cfg.batch.senderOutputDirectory);
if strlength(outputDirectory) == 0
    outputDirectory = fullfile( ...
        cfg.resultsRoot, "batch", variant.name);
end
cris_prepare_output_directory(outputDirectory, cfg.execution.overwrite);

stegoDirectory = fullfile(outputDirectory, "stego_images");
trustworthyDirectory = fullfile(outputDirectory, "trustworthy_images");
secretDirectory = fullfile(outputDirectory, "secret_images");
metadataDirectory = fullfile(outputDirectory, "sender_metadata");
ensureDirectories([stegoDirectory, trustworthyDirectory, ...
    secretDirectory, metadataDirectory]);

fprintf("Batch embedding: preparing %s-CRIS plans.\n", variant.name);
plans = cris_prepare_variant_plans(cfg, variant, "embed");
previousRandomState = rng;
restoreRandomState = onCleanup(@() rng(previousRandomState));
rng(cfg.execution.randomSeed, "twister");

coverPaths = strings(imageCount, 1);
secretPaths = strings(imageCount, 1);
stegoPaths = strings(imageCount, 1);
trustworthyPaths = strings(imageCount, 1);
stegoPsnr = zeros(imageCount, 1);
trustworthyPsnr = zeros(imageCount, 1);
embeddingTimeSeconds = zeros(imageCount, 1);
robustnessEmbeddingTimeSeconds = zeros(imageCount, 1);
credibilityEmbeddingTimeSeconds = zeros(imageCount, 1);

for imageIndex = 1:imageCount
    coverPaths(imageIndex) = fullfile( ...
        coverFiles(imageIndex).folder, coverFiles(imageIndex).name);
    secretImage = uint8(randi([0, 1], cfg.batch.secretImageSize));
    secretMessage = double(secretImage(:).');
    coverImage = imread(coverPaths(imageIndex));
    embeddingTimer = tic;
    embedded = cris_embed_image( ...
        coverImage, secretMessage, cfg, variant, plans);
    embeddingTimeSeconds(imageIndex) = toc(embeddingTimer);
    robustnessEmbeddingTimeSeconds(imageIndex) = ...
        embedded.robustnessEmbeddingTimeSeconds;
    credibilityEmbeddingTimeSeconds(imageIndex) = ...
        embedded.credibilityEmbeddingTimeSeconds;

    outputName = stems(imageIndex) + ".png";
    secretPaths(imageIndex) = fullfile(secretDirectory, outputName);
    stegoPaths(imageIndex) = fullfile(stegoDirectory, outputName);
    trustworthyPaths(imageIndex) = fullfile( ...
        trustworthyDirectory, outputName);
    imwrite(uint8(double(secretImage) * 255), secretPaths(imageIndex));
    imwrite(embedded.stegoImage, stegoPaths(imageIndex));
    imwrite(embedded.trustworthyImage, trustworthyPaths(imageIndex));

    senderMetadata.stateFingerprint = embedded.stateFingerprint;
    senderMetadata.variant = variant;
    save(fullfile(metadataDirectory, stems(imageIndex) + ".mat"), ...
        "senderMetadata");
    stegoPsnr(imageIndex) = psnr( ...
        embedded.stegoImage, embedded.coverImage);
    trustworthyPsnr(imageIndex) = psnr( ...
        embedded.trustworthyImage, embedded.coverImage);

    if shouldReportProgress(imageIndex, imageCount, cfg.execution.progressEvery)
        fprintf("  Embedded %d/%d images.\n", imageIndex, imageCount);
    end
end
clear restoreRandomState;

manifest = table((1:imageCount).', string({coverFiles.name}).', ...
    coverPaths, secretPaths, stegoPaths, trustworthyPaths, ...
    stegoPsnr, trustworthyPsnr, embeddingTimeSeconds, ...
    robustnessEmbeddingTimeSeconds, credibilityEmbeddingTimeSeconds, ...
    'VariableNames', {'ImageIndex', 'CoverName', 'CoverFile', ...
    'SecretImageFile', 'StegoFile', 'TrustworthyFile', ...
    'StegoPSNR', 'TrustworthyPSNR', 'EmbeddingTimeSeconds', ...
    'RobustnessEmbeddingTimeSeconds', ...
    'CredibilityEmbeddingTimeSeconds'});
summary = table(variant.name, imageCount, cfg.execution.randomSeed, ...
    mean(stegoPsnr), mean(trustworthyPsnr), ...
    mean(embeddingTimeSeconds), mean(robustnessEmbeddingTimeSeconds), ...
    mean(credibilityEmbeddingTimeSeconds), string(outputDirectory), ...
    'VariableNames', {'Variant', 'ImageCount', 'RandomSeed', ...
    'MeanStegoPSNR', 'MeanTrustworthyPSNR', ...
    'MeanEmbeddingTimeSeconds', 'MeanRobustnessEmbeddingTimeSeconds', ...
    'MeanCredibilityEmbeddingTimeSeconds', 'OutputDirectory'});

manifestCsv = fullfile(outputDirectory, "batch_embedding_manifest.csv");
summaryCsv = fullfile(outputDirectory, "batch_embedding_summary.csv");
workbook = fullfile(outputDirectory, "batch_embedding_results.xlsx");
summaryForExport = cris_format_metric_columns(summary, ...
    ["MeanStegoPSNR", "MeanTrustworthyPSNR", ...
     "MeanEmbeddingTimeSeconds", "MeanRobustnessEmbeddingTimeSeconds", ...
     "MeanCredibilityEmbeddingTimeSeconds"], 4);
writetable(manifest, manifestCsv);
writetable(summaryForExport, summaryCsv);
writetable(summaryForExport, workbook, "Sheet", "Summary");
writetable(manifest, workbook, "Sheet", "PerImage");
cris_save_run_config(cfg, fullfile(outputDirectory, "run_config.mat"));
save(fullfile(outputDirectory, "batch_embedding_results.mat"), ...
    "summary", "manifest", "variant");

result.summary = summary;
result.perImage = manifest;
result.outputDirectory = outputDirectory;
result.manifestFile = manifestCsv;
result.summaryFile = summaryCsv;
end

function validateBatchConfiguration(cfg)
validateattributes(cfg.execution.maxImages, {'numeric'}, ...
    {'scalar', 'positive'});
validateattributes(cfg.execution.randomSeed, {'numeric'}, ...
    {'scalar', 'integer', 'nonnegative'});
validateattributes(cfg.batch.secretImageSize, {'numeric'}, ...
    {'row', 'numel', 2, 'integer', 'positive'});
if prod(cfg.batch.secretImageSize) ~= cfg.messageLength
    error("CRIS:InvalidSecretImageSize", ...
        "Secret image dimensions must contain exactly %d pixels.", ...
        cfg.messageLength);
end
end

function stems = validateUniqueStems(files, directory)
stems = strings(numel(files), 1);
for index = 1:numel(files)
    [~, stems(index)] = fileparts(files(index).name);
end
if numel(unique(lower(stems))) ~= numel(stems)
    error("CRIS:DuplicateImageStem", ...
        "Image filenames in %s must have unique stems.", directory);
end
end

function ensureDirectories(directories)
for directory = directories
    if ~isfolder(directory)
        mkdir(directory);
    end
end
end

function report = shouldReportProgress(index, count, interval)
report = index == count || (interval > 0 && mod(index, interval) == 0);
end
