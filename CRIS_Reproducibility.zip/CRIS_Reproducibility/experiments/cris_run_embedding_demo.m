function result = cris_run_embedding_demo(cfg)
% Run a single-image sender-side demonstration and save all artifacts.

variant = cris_variant_config(cfg.variant);
if strlength(cfg.demo.coverImage) == 0 || strlength(cfg.demo.secretFile) == 0
    error("CRIS:MissingDemoInput", ...
        "Set cfg.demo.coverImage and cfg.demo.secretFile before embedding.");
end

coverImage = imread(cfg.demo.coverImage);
secret = cris_load_secret(cfg.demo.secretFile, cfg.messageLength);
plans = cris_prepare_variant_plans(cfg, variant, "embed");
embedded = cris_embed_image(coverImage, secret, cfg, variant, plans);

outputDirectory = fullfile(cfg.resultsRoot, "demo", variant.name);
cris_prepare_output_directory(outputDirectory, cfg.execution.overwrite);
imwrite(embedded.stegoImage, fullfile(outputDirectory, "stego_image.png"));
imwrite(embedded.trustworthyImage, ...
    fullfile(outputDirectory, "trustworthy_image.png"));
writematrix(secret, fullfile(outputDirectory, "secret_message.csv"));
stateFingerprint = embedded.stateFingerprint;
save(fullfile(outputDirectory, "sender_metadata.mat"), ...
    "stateFingerprint", "variant");
cris_save_run_config(cfg, fullfile(outputDirectory, "run_config.mat"));

stegoPsnr = psnr(embedded.stegoImage, embedded.coverImage);
trustworthyPsnr = psnr(embedded.trustworthyImage, embedded.coverImage);
result.summary = table(variant.name, stegoPsnr, trustworthyPsnr, ...
    string(outputDirectory), 'VariableNames', ...
    {'Variant', 'StegoPSNR', 'TrustworthyPSNR', 'OutputDirectory'});
result.outputDirectory = outputDirectory;
end
