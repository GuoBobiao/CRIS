function result = cris_run_extraction_demo(cfg)
% Run the receiver side without loading sender ground truth.

variant = cris_variant_config(cfg.variant);
if strlength(cfg.demo.receivedImage) == 0
    error("CRIS:MissingDemoInput", ...
        "Set cfg.demo.receivedImage before extraction.");
end

receivedImage = imread(cfg.demo.receivedImage);
plans = cris_prepare_variant_plans(cfg, variant, "extract");
extracted = cris_extract_image(receivedImage, cfg, variant, plans);

outputDirectory = fullfile(cfg.resultsRoot, "demo", variant.name, "receiver");
cris_prepare_output_directory(outputDirectory, cfg.execution.overwrite);
writematrix(extracted.message, ...
    fullfile(outputDirectory, "extracted_message.csv"));
writematrix(extracted.pairCredibility, ...
    fullfile(outputDirectory, "pair_credibility.csv"));
save(fullfile(outputDirectory, "receiver_output.mat"), "extracted", "variant");
cris_save_run_config(cfg, fullfile(outputDirectory, "run_config.mat"));

result.summary = table(variant.name, extracted.credibility, ...
    extracted.isAccepted, string(outputDirectory), 'VariableNames', ...
    {'Variant', 'Credibility', 'Accepted', 'OutputDirectory'});
result.outputDirectory = outputDirectory;
end
