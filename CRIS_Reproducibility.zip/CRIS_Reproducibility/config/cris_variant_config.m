function variant = cris_variant_config(name)
% Return the paper parameters and historical data layout for one PHT variant.

name = upper(string(name));

switch name
    case "PCET"
        variant.name = "PCET";
        variant.model = 1;
        variant.messageOrder = 23;
        variant.fingerprintOrder = 20;
        variant.fingerprintStartPosition = 200;
        variant.imageDirectory = "Image";
        variant.messageSteps = pcetAndPstSteps();
    case "PCT"
        variant.name = "PCT";
        variant.model = 2;
        variant.messageOrder = 27;
        variant.fingerprintOrder = 30;
        variant.fingerprintStartPosition = 265;
        variant.imageDirectory = "Image";
        variant.messageSteps = pctSteps();
    case "PST"
        variant.name = "PST";
        variant.model = 3;
        variant.messageOrder = 28;
        variant.fingerprintOrder = 30;
        variant.fingerprintStartPosition = 250;
        variant.imageDirectory = "image";
        variant.messageSteps = pcetAndPstSteps();
    otherwise
        error("CRIS:UnknownVariant", ...
            "Unknown variant '%s'. Use PCET, PCT, or PST.", name);
end

variant.messageSteps = double(variant.messageSteps(:).');
variant.dataDirectory = "CRIS-" + variant.name;
end

function steps = pcetAndPstSteps()
steps = 11 * ones(1, 256);
steps([91, 106, 122, 139, 147, 148, 151, 157, 167, 172, 176, 177, ...
    183, 186, 192, 200, 208, 209, 215, 216, 219, 220, 223, 224, ...
    239, 245, 246, 247, 248, 249, 250, 253, 254]) = 12;
end

function steps = pctSteps()
steps = [ ...
    12 12 11 11 11 12 12 12 12 12 11 11 11 11 11 11 11 11 11 12 ...
    12 12 11 12 12 11 12 11 12 12 11 12 11 11 12 12 12 11 12 11 ...
    12 11 12 12 11 12 12 11 11 12 11 12 12 11 12 12 12 11 12 12 ...
    11 12 12 11 11 12 11 12 12 12 11 12 12 11 12 12 11 12 11 12 ...
    12 11 12 11 11 12 11 12 11 11 11 12 11 12 11 11 12 11 12 11 ...
    11 11 12 12 12 11 12 11 11 11 12 11 12 11 12 11 12 11 11 11 ...
    12 11 12 11 11 12 12 12 11 12 12 12 11 12 11 12 12 12 12 12 ...
    11 11 11 11 11 12 12 12 11 12 12 11 11 12 11 12 12 11 12 11 ...
    12 12 12 11 12 12 11 12 12 12 11 12 11 11 12 11 12 12 11 12 ...
    12 12 11 12 11 12 12 12 11 11 12 11 11 12 12 12 11 11 12 12 ...
    11 12 11 12 12 12 11 11 12 11 12 12 12 11 12 12 11 12 11 12 ...
    12 11 12 12 11 12 12 11 12 11 12 12 11 12 11 12 12 11 12 11 ...
    12 11 11 12 11 11 12 11 12 11 12 11 12 12 12 11];
end
