function catalog = cris_table_iii_catalog()
% Define the 17 principal-table degradations and historical folder names.

numbers = (1:17).';
labels = [ ...
    "JPEG (QF=80)"
    "JPEG (QF=60)"
    "JPEG (QF=40)"
    "Scaling (CF=0.8)"
    "Scaling (CF=0.7)"
    "Scaling (CF=0.6)"
    "JPEG (80) + Scaling (0.8)"
    "Sanit_Zhu"
    "Sanit_Cheng"
    "LSB + Sanit_Zhu"
    "LSB + Sanit_Cheng"
    "Steghide + Sanit_Zhu"
    "Steghide + Sanit_Cheng"
    "JPEG (QF=60) + Sanit_Zhu"
    "JPEG (QF=80) + Sanit_Cheng"
    "Scaling (CF=0.7) + Sanit_Zhu"
    "JPEG (80) + Scaling (0.8) + Sanit_Zhu"];

aliases = { ...
    ["NO1_JPEG80", "NO1_JPEG80jpg"]
    ["NO2_JPEG60", "NO2_JPEG60jpg"]
    ["NO3_JPEG40", "NO3_JPEG40jpg"]
    "NO4_Scaling0.8"
    "NO5_Scaling0.7"
    "NO6_Scaling0.6"
    "NO7_JPEG80_Scaling0.8"
    "NO8_Sanit_Zhu"
    "NO9_Sanit_Cheng"
    ["NO10_LSB+Sanit_Zhu", "NO10_LSB_Sanit_Zhu"]
    ["NO11_LSB+Sanit_Cheng", "NO11_LSB_Sanit_Cheng"]
    ["NO12_Steghide+Sanit_Zhu", "NO12_Steghide_Sanit_Zhu"]
    ["NO13_Steghide+Sanit_Cheng", "NO13_Steghide_Sanit_Cheng"]
    "NO14_JPEG60_Sanit_Zhu"
    "NO15_JPEG80_Sanit_Cheng"
    "NO16_Scaling0.7_Sanit_Zhu"
    "NO17_JPEG80_Scaling0.8_Sanit_Zhu"};

catalog = table(numbers, labels, aliases, ...
    'VariableNames', {'Number', 'Label', 'FolderAliases'});
end
