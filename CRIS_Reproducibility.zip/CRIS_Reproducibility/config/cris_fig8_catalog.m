function catalog = cris_fig8_catalog()
% Define the additional degradation protocol used to generate Fig. 8.

types = strings(24, 1);
parameters = zeros(24, 1);
names = strings(24, 1);
cursor = 0;

cursor = appendLevels(cursor, "gaussian", ...
    [0.0005, 0.0006, 0.0007, 0.0008, 0.0009, 0.001], "Gaussian");
cursor = appendLevels(cursor, "saltpepper", ...
    [0.0005, 0.0006, 0.0007, 0.0008, 0.0009, 0.001], "SaltPepper");
cursor = appendLevels(cursor, "cropping", ...
    [0.1, 0.2, 0.3, 0.4, 0.5, 0.6], "Cropping");
appendLevels(cursor, "rotation", [30, 60, 90, 120, 150, 180], "Rotation");

catalog = table(types, parameters, names, ...
    'VariableNames', {'Type', 'Parameter', 'Name'});

    function next = appendLevels(startIndex, type, levels, prefix)
        for levelIndex = 1:numel(levels)
            row = startIndex + levelIndex;
            types(row) = type;
            parameters(row) = levels(levelIndex);
            if type == "gaussian" || type == "saltpepper"
                token = replace(compose("%.4f", levels(levelIndex)), ".", "_");
            elseif type == "cropping"
                token = replace(compose("%.1f", levels(levelIndex)), ".", "_");
            else
                token = compose("%d", levels(levelIndex));
            end
            names(row) = prefix + "_" + token;
        end
        next = startIndex + numel(levels);
    end
end
