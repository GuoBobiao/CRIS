function cfg = cris_default_config(projectRoot)
% Return all shared settings used by the public CRIS implementation.

arguments
    projectRoot (1,1) string = string(fileparts(fileparts(mfilename("fullpath"))))
end

cfg.projectRoot = projectRoot;
cfg.dataRoot = fullfile(fileparts(projectRoot), "raw data");
cfg.resultsRoot = fullfile(projectRoot, "results");
cfg.variants = ["PCET", "PCT", "PST"];
cfg.variant = "PCET";

cfg.imageSize = [1024, 1024];
cfg.blockGrid = [4, 4];
cfg.blockPairs = 8;
cfg.messageLength = 2048;
cfg.messageBitsPerPair = 256;
cfg.fingerprintLength = 50;
cfg.minimumTotalOrder = 9;
cfg.messageNormalization = 4000;
cfg.baseMessageStep = 10;

cfg.fingerprintDct.normalization = 10;
cfg.fingerprintDct.step1 = 2000;
cfg.fingerprintDct.step2 = 2000;
cfg.fingerprintDct.selectedRegionOrdinals = [ ...
    10, 11, 30, 42, 54, 62, 70, 78, 84, 85, 86, 87, 92, ...
    94, 100, 106, 107, 115, 116, 126, 127, 140, 141, 158, 159];
cfg.fingerprintDct.firstCoefficient = 4;

cfg.receiver.credibilityThreshold = 0;
cfg.receiver.abortBelowThreshold = false;

cfg.execution.maxImages = Inf;
cfg.execution.overwrite = false;
cfg.execution.randomSeed = 20260816;
cfg.execution.savePerImageResults = true;
cfg.execution.progressEvery = 10;

cfg.batch.coverDirectory = fullfile(cfg.dataRoot, "Cover_Image");
cfg.batch.receivedImageDirectory = "";
cfg.batch.secretImageDirectory = "";
cfg.batch.senderOutputDirectory = "";
cfg.batch.receiverOutputDirectory = "";
cfg.batch.secretImageSize = [32, 64];

cfg.evaluation.lpips.enabled = true;
cfg.evaluation.lpips.pythonExecutable = "python";
cfg.evaluation.lpips.network = "alex";

cfg.demo.coverImage = "";
cfg.demo.secretFile = "";
cfg.demo.receivedImage = "";
end
