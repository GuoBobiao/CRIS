clc;
clear;
close all;

%% ===================== Parameter Settings =====================
projectRoot = setup_cris();
cfg = cris_default_config(projectRoot);

% Portable defaults: place "raw data" next to CRIS_Reproducibility.
% These two paths can be changed without modifying the embedding algorithm.
inputFolder = fullfile(cfg.dataRoot, 'Cover_Image');
outputFolder = fullfile(cfg.resultsRoot, 'baselines', 'LSB', 'Stego_Image');

payload = 0.5;   % Embedding payload: 0.5 BPP

% Refresh the baseline output when this entry point is rerun.
cris_prepare_output_directory(outputFolder, true);

%% ===================== Read All Images =====================
extensions = {'*.png', '*.jpg', '*.jpeg', '*.bmp', '*.tif', '*.tiff'};

imageFiles = [];
for i = 1:length(extensions)
    imageFiles = [imageFiles; dir(fullfile(inputFolder, extensions{i}))]; %#ok<AGROW>
end

fprintf('=============================================\n');
fprintf('Number of images: %d\n', length(imageFiles));
fprintf('Payload: %.2f BPP\n', payload);
fprintf('=============================================\n');

%% ===================== Batch LSB Embedding =====================
for idx = 1:length(imageFiles)

    %% Read image
    inputPath = fullfile(inputFolder, imageFiles(idx).name);
    cover = imread(inputPath);

    % Ensure uint8 image
    if ~isa(cover, 'uint8')
        cover = im2uint8(cover);
    end

    [H, W, ~] = size(cover);

    %% 0.5 BPP
    numPixels = H * W;
    messageLength = floor(payload * numPixels);

    %% Randomly generate secret message
    message = randi([0, 1], messageLength, 1, 'uint8');

    %% Convert image to one-dimensional sequence
    coverVector = cover(:);
    totalSamples = numel(coverVector);

    if messageLength > totalSamples
        error('The payload exceeds the available embedding capacity.');
    end

    %% Randomly select embedding positions
    embeddingPositions = randperm(totalSamples, messageLength);

    %% Classical LSB replacement
    stegoVector = coverVector;

    stegoVector(embeddingPositions) = ...
        bitset(stegoVector(embeddingPositions), 1, message);

    %% Restore image
    stego = reshape(stegoVector, size(cover));

    %% Save as PNG
    [~, fileName, ~] = fileparts(imageFiles(idx).name);
    outputPath = fullfile(outputFolder, [fileName, '.png']);

    imwrite(stego, outputPath);

    %% Statistics
    changedSamples = sum(coverVector ~= stegoVector);
    modificationRate = changedSamples / numPixels;

    fprintf('[%4d/%4d] %-30s  Message = %d bits, Changed = %d, Rate = %.4f\n', ...
        idx, length(imageFiles), imageFiles(idx).name, ...
        messageLength, changedSamples, modificationRate);

end

fprintf('\n=============================================\n');
fprintf('LSB embedding completed.\n');
fprintf('Stego images saved to:\n%s\n', outputFolder);
fprintf('=============================================\n');
