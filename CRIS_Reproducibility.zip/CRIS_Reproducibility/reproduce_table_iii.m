% Reproduce the CRIS quality, robustness, and credibility results in Table III.

projectRoot = setup_cris();
cfg = cris_default_config(projectRoot);

% Set to a positive integer for a quick smoke test; use Inf for the paper run.
cfg.execution.maxImages = Inf;

% Refresh the reproducibility artifacts when this entry point is rerun.
cfg.execution.overwrite = true;

result = cris_reproduce_table_iii(cfg);
metricVariables = string(result.summary.Properties.VariableNames(3:end));
displaySummary = cris_format_metric_columns( ...
    result.summary, metricVariables, 4);
disp(displaySummary);
