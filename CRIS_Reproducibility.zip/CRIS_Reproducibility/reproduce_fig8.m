% Reproduce Fig. 8 under noise, cropping, and rotation degradations.

projectRoot = setup_cris();
cfg = cris_default_config(projectRoot);

% Set to a positive integer for a quick smoke test; use Inf for the paper run.
cfg.execution.maxImages = Inf;

% Refresh the reproducibility artifacts when this entry point is rerun.
% The lower-level API keeps overwrite protection disabled by default.
cfg.execution.overwrite = true;

result = cris_reproduce_fig8(cfg);
displaySummary = cris_format_metric_columns(result.summary, ...
    ["Robustness", "Credibility", "Difference"], 4);
disp(displaySummary);
