function message = cris_extract_backup_fingerprint(imageBlock, plan, ...
    normalizationFactor, step1, step2)
% Extract one fingerprint half from the independent DCT-domain regions.

maximumBits = size(plan.regions, 1) * plan.bitsPerRegion;
message = zeros(1, maximumBits);
messageIndex = 1;

for regionIndex = 1:size(plan.regions, 1)
    row = plan.regions(regionIndex, 1);
    column = plan.regions(regionIndex, 2);
    rowRange = (row - 1) * 8 + (1:8);
    columnRange = (column - 1) * 8 + (1:8);
    dctVector = cris_zigzag_scan( ...
        dct2(imageBlock(rowRange, columnRange)), plan.zigzagOrder);

    for bitOffset = 1:plan.bitsPerRegion
        coefficientOneIndex = plan.firstCoefficient + 2 * (bitOffset - 1);
        coefficientTwoIndex = coefficientOneIndex + 1;
        valueOne = normalizationFactor * dctVector(coefficientOneIndex);
        valueTwo = normalizationFactor * dctVector(coefficientTwoIndex);
        baseOne = floor(valueOne / step1) * step1;
        baseTwo = floor(valueTwo / step2) * step2;

        message(messageIndex) = ...
            ((valueOne - baseOne) / step1) <= ...
            ((valueTwo - baseTwo) / step2);
        messageIndex = messageIndex + 1;
    end
end
end

