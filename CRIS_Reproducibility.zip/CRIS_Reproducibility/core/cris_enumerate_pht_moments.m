function momentTable = cris_enumerate_pht_moments(order, model)
% Enumerate PHT order-repetition pairs in the exact legacy sorting order.

pairs = zeros(2, (2 * order + 1)^2);
count = 0;

switch model
    case 1
        for n = -order:order
            for m = -order:order
                if abs(n) + abs(m) <= order
                    count = count + 1;
                    pairs(:, count) = [n; m];
                end
            end
        end
    case 2
        for n = 0:order
            for m = -order:order
                if n + abs(m) <= order
                    count = count + 1;
                    pairs(:, count) = [n; m];
                end
            end
        end
    case 3
        for n = 1:order
            for m = -order:order
                if n + abs(m) <= order
                    count = count + 1;
                    pairs(:, count) = [n; m];
                end
            end
        end
    otherwise
        error("CRIS:UnknownPHTModel", "PHT model must be 1, 2, or 3.");
end

pairs = pairs(:, 1:count);
sortKey = [abs(pairs(1, :) + 1i * pairs(2, :)); pairs].';
[~, orderIndex] = sortrows(sortKey, [1, 2, 3]);
momentTable = pairs(:, orderIndex);
end

