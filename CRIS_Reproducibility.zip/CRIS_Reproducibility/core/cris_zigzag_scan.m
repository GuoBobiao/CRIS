function vector = cris_zigzag_scan(matrix, order)
% Convert one 8-by-8 DCT block to the released zigzag ordering.

vector = zeros(1, 64);
vector(order(:)) = matrix(:);
end

