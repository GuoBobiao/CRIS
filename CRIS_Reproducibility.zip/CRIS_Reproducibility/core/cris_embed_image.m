function output = cris_embed_image(coverImage, secretMessage, cfg, variant, plans)
% Execute Algorithm 1 and generate stego and trustworthy images.

if numel(secretMessage) ~= cfg.messageLength
    error("CRIS:InvalidMessageLength", ...
        "The secret message must contain exactly %d bits.", cfg.messageLength);
end

coverImage = cris_normalize_input_image(coverImage, cfg.imageSize);
secretMessage = double(secretMessage(:).');
if any(secretMessage ~= 0 & secretMessage ~= 1)
    error("CRIS:NonBinaryMessage", "The secret message must be binary.");
end

rowCuts = repmat(cfg.imageSize(1) / cfg.blockGrid(1), 1, cfg.blockGrid(1));
columnCuts = repmat(cfg.imageSize(2) / cfg.blockGrid(2), 1, cfg.blockGrid(2));
coverBlocks = mat2cell(coverImage, rowCuts, columnCuts);
stegoBlocks = coverBlocks;
trustworthyBlocks = coverBlocks;
positions = cris_block_pair_positions();
fingerprints = zeros(cfg.fingerprintLength / 2, cfg.blockPairs * 2);
robustnessEmbeddingTimeSeconds = 0;
credibilityEmbeddingTimeSeconds = 0;

for pairIndex = 1:cfg.blockPairs
    firstPosition = positions(2 * pairIndex - 1, :);
    secondPosition = positions(2 * pairIndex, :);
    blockOne = coverBlocks{firstPosition(1), firstPosition(2)};
    blockTwo = coverBlocks{secondPosition(1), secondPosition(2)};
    messageRange = (pairIndex - 1) * cfg.messageBitsPerPair + ...
        (1:cfg.messageBitsPerPair);

    robustnessTimer = tic;
    [stegoOne, stegoTwo] = cris_embed_message_pair( ...
        blockOne, blockTwo, secretMessage(messageRange), plans.message, ...
        cfg.messageNormalization, variant.messageSteps);
    robustnessEmbeddingTimeSeconds = robustnessEmbeddingTimeSeconds + ...
        toc(robustnessTimer);
    stegoBlocks{firstPosition(1), firstPosition(2)} = stegoOne;
    stegoBlocks{secondPosition(1), secondPosition(2)} = stegoTwo;

    credibilityTimer = tic;
    fingerprint = cris_generate_state_fingerprint( ...
        stegoOne, stegoTwo, plans.fingerprint, cfg.messageNormalization);
    halfLength = cfg.fingerprintLength / 2;
    firstHalf = fingerprint(1:halfLength);
    secondHalf = fingerprint((halfLength + 1):end);
    fingerprints(:, 2 * pairIndex - 1) = firstHalf;
    fingerprints(:, 2 * pairIndex) = secondHalf;

    trustworthyOne = cris_embed_backup_fingerprint(stegoOne, firstHalf, ...
        plans.dct, cfg.fingerprintDct.normalization, ...
        cfg.fingerprintDct.step1, cfg.fingerprintDct.step2);
    trustworthyTwo = cris_embed_backup_fingerprint(stegoTwo, secondHalf, ...
        plans.dct, cfg.fingerprintDct.normalization, ...
        cfg.fingerprintDct.step1, cfg.fingerprintDct.step2);
    credibilityEmbeddingTimeSeconds = credibilityEmbeddingTimeSeconds + ...
        toc(credibilityTimer);
    trustworthyBlocks{firstPosition(1), firstPosition(2)} = trustworthyOne;
    trustworthyBlocks{secondPosition(1), secondPosition(2)} = trustworthyTwo;
end

output.coverImage = coverImage;
output.stegoImage = cell2mat(stegoBlocks);
output.trustworthyImage = cell2mat(trustworthyBlocks);
output.stateFingerprint = fingerprints;
output.robustnessEmbeddingTimeSeconds = robustnessEmbeddingTimeSeconds;
output.credibilityEmbeddingTimeSeconds = credibilityEmbeddingTimeSeconds;
end
