function matrix = cris_inverse_zigzag(vector, order)
% Restore one 8-by-8 DCT block from the released zigzag ordering.

matrix = zeros(8, 8);
matrix(:) = vector(order(:));
end

