function [stegoOne, stegoTwo] = cris_embed_message_pair( ...
    blockOne, blockTwo, bits, plan, normalizationFactor, steps)
% Embed one message segment with the original BQIM-AS modulation rule.

blockOne = uint8(blockOne);
blockTwo = uint8(blockTwo);
momentsOne = cris_compute_pht_moments(blockOne, plan);
momentsTwo = cris_compute_pht_moments(blockTwo, plan);
indices = plan.selectedLocalIndices;
partners = plan.partnerLocalIndices;
steps = steps(1:numel(bits));

featureOne = abs(normalizationFactor .* momentsOne(indices) ./ ...
    momentsOne(plan.referenceLocalIndex));
featureTwo = abs(normalizationFactor .* momentsTwo(indices) ./ ...
    momentsTwo(plan.referenceLocalIndex));

perturbationOne = complex(zeros(size(blockOne)));
perturbationTwo = complex(zeros(size(blockTwo)));

for bitIndex = 1:numel(bits)
    step = steps(bitIndex);
    valueOne = featureOne(bitIndex);
    valueTwo = featureTwo(bitIndex);
    indexOne = floor(valueOne / step);
    indexTwo = floor(valueTwo / step);

    if bits(bitIndex) == 1
        if valueOne <= (indexOne + 0.75) * step
            embeddedOne = indexOne * step + step / 4;
        else
            embeddedOne = (indexOne + 1) * step + step / 4;
        end
        if valueTwo <= (indexTwo + 0.25) * step
            if indexTwo > 0
                embeddedTwo = (indexTwo - 1) * step + 3 * step / 4;
            else
                embeddedTwo = indexTwo * step + 3 * step / 4;
            end
        else
            embeddedTwo = indexTwo * step + 3 * step / 4;
        end
    else
        if valueOne <= (indexOne + 0.25) * step
            if indexOne > 0
                embeddedOne = (indexOne - 1) * step + 3 * step / 4;
            else
                embeddedOne = indexOne * step + 3 * step / 4;
            end
        else
            embeddedOne = indexOne * step + 3 * step / 4;
        end
        if valueTwo <= (indexTwo + 0.75) * step
            embeddedTwo = indexTwo * step + step / 4;
        else
            embeddedTwo = (indexTwo + 1) * step + step / 4;
        end
    end

    selected = indices(bitIndex);
    partner = partners(bitIndex);
    basisSelected = reshape(conj(plan.conjugateBasis(:, selected)), ...
        plan.blockSize, plan.blockSize);
    basisPartner = reshape(conj(plan.conjugateBasis(:, partner)), ...
        plan.blockSize, plan.blockSize);
    perturbationOne = perturbationOne + ...
        (embeddedOne / valueOne - 1) .* ...
        (momentsOne(selected) .* basisSelected + ...
        conj(momentsOne(selected)) .* basisPartner);
    perturbationTwo = perturbationTwo + ...
        (embeddedTwo / valueTwo - 1) .* ...
        (momentsTwo(selected) .* basisSelected + ...
        conj(momentsTwo(selected)) .* basisPartner);
end

stegoOne = uint8(round(double(blockOne) + perturbationOne));
stegoTwo = uint8(round(double(blockTwo) + perturbationTwo));
end
