function plan = cris_prepare_pht_plan(blockSize, model, order, ...
    stablePositions, minimumTotalOrder, includeConjugatePartners)
% Precompute only the PHT bases required by one algorithm stage.

arguments
    blockSize (1,1) double {mustBeInteger, mustBePositive}
    model (1,1) double {mustBeMember(model, [1, 2, 3])}
    order (1,1) double {mustBeInteger, mustBePositive}
    stablePositions (1,:) double {mustBeInteger, mustBePositive}
    minimumTotalOrder (1,1) double {mustBeNonnegative}
    includeConjugatePartners (1,1) logical = false
end

momentTable = cris_enumerate_pht_moments(order, model);
stableGlobalIndices = cris_select_stable_moments( ...
    momentTable, model, minimumTotalOrder);

if max(stablePositions) > numel(stableGlobalIndices)
    error('CRIS:InsufficientStableMoments', ...
        ['Order %d for model %d provides %d stable moments, but position ' ...
         '%d was requested.'], order, model, numel(stableGlobalIndices), ...
        max(stablePositions));
end

selectedGlobalIndices = stableGlobalIndices(stablePositions);
partnerGlobalIndices = zeros(size(selectedGlobalIndices));

if includeConjugatePartners
    for index = 1:numel(selectedGlobalIndices)
        selected = selectedGlobalIndices(index);
        n = momentTable(1, selected);
        m = momentTable(2, selected);
        if model == 1
            partner = find(momentTable(1, :) == -n & ...
                momentTable(2, :) == -m, 1, "first");
        else
            partner = find(momentTable(1, :) == n & ...
                momentTable(2, :) == -m, 1, "first");
        end
        if isempty(partner)
            error("CRIS:MissingConjugateMoment", ...
                "No conjugate partner was found for moment (%d,%d).", n, m);
        end
        partnerGlobalIndices(index) = partner;
    end
end

requiredGlobalIndices = unique([1, selectedGlobalIndices, ...
    partnerGlobalIndices(partnerGlobalIndices > 0)], "stable");
globalToLocal = zeros(1, size(momentTable, 2));
globalToLocal(requiredGlobalIndices) = 1:numel(requiredGlobalIndices);

coordinate = -1:(2 / (blockSize - 1)):1;
[x, y] = meshgrid(coordinate, coordinate);
[theta, radius] = cart2pol(x, y);
mask = uint8(radius <= 1);
radiusSquared = radius .^ 2;

conjugateBasis = complex(zeros(blockSize^2, numel(requiredGlobalIndices)));
normalization = zeros(1, numel(requiredGlobalIndices));

for localIndex = 1:numel(requiredGlobalIndices)
    globalIndex = requiredGlobalIndices(localIndex);
    n = momentTable(1, globalIndex);
    m = momentTable(2, globalIndex);
    switch model
        case 1
            basis = exp(1i * (2 * pi * n .* radiusSquared + m .* theta));
            normalization(localIndex) = 4 / (pi * blockSize^2);
        case 2
            basis = cos(pi * n .* radiusSquared) .* exp(1i * m .* theta);
            if n == 0
                normalization(localIndex) = 4 / (pi * blockSize^2);
            else
                normalization(localIndex) = 8 / (pi * blockSize^2);
            end
        case 3
            basis = sin(pi * n .* radiusSquared) .* exp(1i * m .* theta);
            normalization(localIndex) = 8 / (pi * blockSize^2);
    end
    basis = basis .* double(mask);
    conjugateBasis(:, localIndex) = conj(basis(:));
end

plan.blockSize = blockSize;
plan.model = model;
plan.order = order;
plan.momentTable = momentTable;
plan.mask = mask;
plan.conjugateBasis = conjugateBasis;
plan.normalization = normalization;
plan.referenceLocalIndex = globalToLocal(1);
plan.selectedLocalIndices = globalToLocal(selectedGlobalIndices);
if includeConjugatePartners
    plan.partnerLocalIndices = globalToLocal(partnerGlobalIndices);
else
    plan.partnerLocalIndices = zeros(size(selectedGlobalIndices));
end
plan.computedLocalIndices = unique( ...
    [plan.referenceLocalIndex, plan.selectedLocalIndices], "stable");
plan.stablePositions = stablePositions;
end
