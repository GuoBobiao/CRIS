function outputBlock = cris_embed_backup_fingerprint(imageBlock, message, ...
    plan, normalizationFactor, step1, step2)
% Embed one fingerprint half in the independent DCT-domain regions.

outputBlock = imageBlock;
messageIndex = 1;

for regionIndex = 1:size(plan.regions, 1)
    row = plan.regions(regionIndex, 1);
    column = plan.regions(regionIndex, 2);
    rowRange = (row - 1) * 8 + (1:8);
    columnRange = (column - 1) * 8 + (1:8);
    dctBlock = dct2(imageBlock(rowRange, columnRange));
    dctVector = cris_zigzag_scan(dctBlock, plan.zigzagOrder);
    embeddedVector = dctVector;

    for bitOffset = 1:plan.bitsPerRegion
        if messageIndex > numel(message)
            break;
        end

        coefficientOneIndex = plan.firstCoefficient + 2 * (bitOffset - 1);
        coefficientTwoIndex = coefficientOneIndex + 1;
        coefficientOne = dctVector(coefficientOneIndex);
        coefficientTwo = dctVector(coefficientTwoIndex);
        bit = message(messageIndex);
        messageIndex = messageIndex + 1;

        valueOne = normalizationFactor * coefficientOne;
        valueTwo = normalizationFactor * coefficientTwo;
        indexOne = floor(valueOne / step1);
        indexTwo = floor(valueTwo / step2);

        if bit == 1
            if valueOne <= (indexOne + 0.75) * step1
                embeddedOne = indexOne * step1 + step1 / 4;
            else
                embeddedOne = (indexOne + 1) * step1 + step1 / 4;
            end
            if valueTwo <= (indexTwo + 0.25) * step2
                embeddedTwo = (indexTwo - 1) * step2 + 3 * step2 / 4;
            else
                embeddedTwo = indexTwo * step2 + 3 * step2 / 4;
            end
        else
            if valueOne <= (indexOne + 0.25) * step1
                embeddedOne = (indexOne - 1) * step1 + 3 * step1 / 4;
            else
                embeddedOne = indexOne * step1 + 3 * step1 / 4;
            end
            if valueTwo <= (indexTwo + 0.75) * step2
                embeddedTwo = indexTwo * step2 + step2 / 4;
            else
                embeddedTwo = (indexTwo + 1) * step2 + step2 / 4;
            end
        end

        embeddedVector(coefficientOneIndex) = ...
            embeddedOne / normalizationFactor;
        embeddedVector(coefficientTwoIndex) = ...
            embeddedTwo / normalizationFactor;
    end

    reconstructed = idct2(cris_inverse_zigzag( ...
        embeddedVector, plan.zigzagOrder));
    outputBlock(rowRange, columnRange) = reconstructed;
end
end

