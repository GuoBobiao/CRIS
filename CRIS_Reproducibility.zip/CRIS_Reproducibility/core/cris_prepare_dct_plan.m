function plan = cris_prepare_dct_plan(blockSize, fingerprintLength, ...
    selectedRegionOrdinals, firstCoefficient)
% Select the spatially decoupled 8-by-8 regions used for fingerprint backup.

coordinate = -1:(2 / (blockSize - 1)):1;
[x, y] = meshgrid(coordinate, coordinate);
[~, radius] = cart2pol(x, y);
messageDomain = uint8(radius <= 1);

rowCount = blockSize / 8;
columnCount = blockSize / 8;
if mod(rowCount, 1) ~= 0 || mod(columnCount, 1) ~= 0
    error("CRIS:InvalidDctGeometry", ...
        "The PHT block size must be divisible by 8.");
end

availableRegions = zeros(rowCount * columnCount, 2);
regionCount = 0;
for row = 1:rowCount
    for column = 1:columnCount
        region = messageDomain((row - 1) * 8 + (1:8), ...
            (column - 1) * 8 + (1:8));
        if ~any(region(:) == 1)
            regionCount = regionCount + 1;
            availableRegions(regionCount, :) = [row, column];
        end
    end
end
availableRegions = availableRegions(1:regionCount, :);

if max(selectedRegionOrdinals) > regionCount
    error("CRIS:InsufficientDctRegions", ...
        "The configured DCT region ordinal exceeds the available region count.");
end

plan.availableRegions = availableRegions;
plan.regions = availableRegions(selectedRegionOrdinals, :);
plan.bitsPerRegion = ceil(fingerprintLength / regionCount);
plan.firstCoefficient = firstCoefficient;
plan.zigzagOrder = [ ...
     1,  2,  6,  7, 15, 16, 28, 29; ...
     3,  5,  8, 14, 17, 27, 30, 43; ...
     4,  9, 13, 18, 26, 31, 42, 44; ...
    10, 12, 19, 25, 32, 41, 45, 54; ...
    11, 20, 24, 33, 40, 46, 53, 55; ...
    21, 23, 34, 39, 47, 52, 56, 61; ...
    22, 35, 38, 48, 51, 57, 60, 62; ...
    36, 37, 49, 50, 58, 59, 63, 64];
end

