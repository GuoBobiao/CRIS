function indices = cris_select_stable_moments(momentTable, model, minimumTotalOrder)
% Select stable PHT moments using the conditions in the released algorithm.

n = momentTable(1, :);
m = momentTable(2, :);
notMultipleOfFour = mod(m, 4) ~= 0;
aboveMinimumOrder = abs(n) + abs(m) >= minimumTotalOrder;

switch model
    case 1
        admissibleSign = (n == 0 & m > 0) | n > 0;
    case 2
        admissibleSign = n >= 0 & m > 0;
    case 3
        admissibleSign = n >= 1 & m > 0;
    otherwise
        error("CRIS:UnknownPHTModel", "PHT model must be 1, 2, or 3.");
end

indices = find(notMultipleOfFour & aboveMinimumOrder & admissibleSign);
indices = indices(:).';
end

