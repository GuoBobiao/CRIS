function output = cris_extract_image(receivedImage, cfg, variant, plans)
% Execute Algorithm 2 without access to the original message or fingerprint.

receivedImage = cris_normalize_input_image(receivedImage, cfg.imageSize);
rowCuts = repmat(cfg.imageSize(1) / cfg.blockGrid(1), 1, cfg.blockGrid(1));
columnCuts = repmat(cfg.imageSize(2) / cfg.blockGrid(2), 1, cfg.blockGrid(2));
blocks = mat2cell(receivedImage, rowCuts, columnCuts);
positions = cris_block_pair_positions();

message = zeros(1, cfg.messageLength);
pairCredibility = zeros(1, cfg.blockPairs);
degradedFingerprint = zeros(cfg.fingerprintLength, cfg.blockPairs);
backupFingerprint = zeros(cfg.fingerprintLength, cfg.blockPairs);
robustnessExtractionTimeSeconds = 0;
credibilityExtractionTimeSeconds = 0;

for pairIndex = 1:cfg.blockPairs
    firstPosition = positions(2 * pairIndex - 1, :);
    secondPosition = positions(2 * pairIndex, :);
    blockOne = blocks{firstPosition(1), firstPosition(2)};
    blockTwo = blocks{secondPosition(1), secondPosition(2)};

    credibilityTimer = tic;
    degraded = cris_generate_state_fingerprint( ...
        blockOne, blockTwo, plans.fingerprint, cfg.messageNormalization);
    firstHalf = cris_extract_backup_fingerprint(blockOne, plans.dct, ...
        cfg.fingerprintDct.normalization, cfg.fingerprintDct.step1, ...
        cfg.fingerprintDct.step2);
    secondHalf = cris_extract_backup_fingerprint(blockTwo, plans.dct, ...
        cfg.fingerprintDct.normalization, cfg.fingerprintDct.step1, ...
        cfg.fingerprintDct.step2);
    backup = [firstHalf(1:cfg.fingerprintLength / 2), ...
        secondHalf(1:cfg.fingerprintLength / 2)].';

    degradedFingerprint(:, pairIndex) = degraded;
    backupFingerprint(:, pairIndex) = backup;
    pairCredibility(pairIndex) = mean(degraded == backup);
    credibilityExtractionTimeSeconds = credibilityExtractionTimeSeconds + ...
        toc(credibilityTimer);

    messageRange = (pairIndex - 1) * cfg.messageBitsPerPair + ...
        (1:cfg.messageBitsPerPair);
    robustnessTimer = tic;
    message(messageRange) = cris_extract_message_pair( ...
        blockOne, blockTwo, plans.message, cfg.messageNormalization, ...
        variant.messageSteps);
    robustnessExtractionTimeSeconds = robustnessExtractionTimeSeconds + ...
        toc(robustnessTimer);
end

output.message = message;
output.credibility = mean(pairCredibility);
output.pairCredibility = pairCredibility;
output.degradedFingerprint = degradedFingerprint;
output.backupFingerprint = backupFingerprint;
output.isAccepted = output.credibility >= cfg.receiver.credibilityThreshold;
output.robustnessExtractionTimeSeconds = robustnessExtractionTimeSeconds;
output.credibilityExtractionTimeSeconds = credibilityExtractionTimeSeconds;

if cfg.receiver.abortBelowThreshold && ~output.isAccepted
    output.message = [];
end
end
