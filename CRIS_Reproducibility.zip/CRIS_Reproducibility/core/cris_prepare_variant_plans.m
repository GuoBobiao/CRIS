function plans = cris_prepare_variant_plans(cfg, variant, mode)
% Build reusable PHT and DCT plans for one CRIS variant.

arguments
    cfg (1,1) struct
    variant (1,1) struct
    mode (1,1) string {mustBeMember(mode, ["embed", "extract"])}
end

blockSize = cfg.imageSize(1) / cfg.blockGrid(1);
if blockSize ~= cfg.imageSize(2) / cfg.blockGrid(2) || mod(blockSize, 1) ~= 0
    error("CRIS:InvalidBlockGeometry", ...
        "The configured image and grid must produce square integer blocks.");
end

includePartners = mode == "embed";
plans.message = cris_prepare_pht_plan(blockSize, variant.model, ...
    variant.messageOrder, 1:cfg.messageBitsPerPair, ...
    cfg.minimumTotalOrder, includePartners);

fingerprintPositions = variant.fingerprintStartPosition + ...
    (0:(cfg.fingerprintLength - 1));
plans.fingerprint = cris_prepare_pht_plan(blockSize, variant.model, ...
    variant.fingerprintOrder, fingerprintPositions, ...
    cfg.minimumTotalOrder, false);

plans.dct = cris_prepare_dct_plan(blockSize, cfg.fingerprintLength, ...
    cfg.fingerprintDct.selectedRegionOrdinals, ...
    cfg.fingerprintDct.firstCoefficient);
end

