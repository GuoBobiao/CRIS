function fingerprint = cris_generate_state_fingerprint( ...
    blockOne, blockTwo, plan, normalizationFactor)
% Generate the state-aware fingerprint from a pair of image blocks.

momentsOne = cris_compute_pht_moments(blockOne, plan);
momentsTwo = cris_compute_pht_moments(blockTwo, plan);
indices = plan.selectedLocalIndices;

featureOne = abs(normalizationFactor .* momentsOne(indices) ./ ...
    momentsOne(plan.referenceLocalIndex));
featureTwo = abs(normalizationFactor .* momentsTwo(indices) ./ ...
    momentsTwo(plan.referenceLocalIndex));
fingerprint = double(featureOne < featureTwo).';
end

