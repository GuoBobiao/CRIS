function bits = cris_extract_message_pair(blockOne, blockTwo, plan, ...
    normalizationFactor, steps)
% Extract one secret-message segment with the original BQIM-AS rule.

momentsOne = cris_compute_pht_moments(blockOne, plan);
momentsTwo = cris_compute_pht_moments(blockTwo, plan);
indices = plan.selectedLocalIndices;

featureOne = abs(normalizationFactor .* momentsOne(indices) ./ ...
    momentsOne(plan.referenceLocalIndex));
featureTwo = abs(normalizationFactor .* momentsTwo(indices) ./ ...
    momentsTwo(plan.referenceLocalIndex));

steps = steps(1:numel(indices));
baseOne = floor(featureOne ./ steps) .* steps;
baseTwo = floor(featureTwo ./ steps) .* steps;
fractionOne = (featureOne - baseOne) ./ steps;
fractionTwo = (featureTwo - baseTwo) ./ steps;
bits = double(fractionOne <= fractionTwo);
end

