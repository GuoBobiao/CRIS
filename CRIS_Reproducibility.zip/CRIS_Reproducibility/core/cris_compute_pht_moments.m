function moments = cris_compute_pht_moments(imageBlock, plan)
% Compute the PHT moments required by a precomputed plan.

if ~isequal(size(imageBlock, 1), plan.blockSize) || ...
        ~isequal(size(imageBlock, 2), plan.blockSize)
    error("CRIS:UnexpectedBlockSize", ...
        "Expected a %d-by-%d image block.", plan.blockSize, plan.blockSize);
end

maskedImage = uint8(real(imageBlock)) .* uint8(real(plan.mask));
maskedImage = double(maskedImage) .* double(plan.mask);
moments = complex(zeros(1, size(plan.conjugateBasis, 2)));
rawMoments = maskedImage(:).' * ...
    plan.conjugateBasis(:, plan.computedLocalIndices);
moments(plan.computedLocalIndices) = rawMoments .* ...
    plan.normalization(plan.computedLocalIndices);
end
