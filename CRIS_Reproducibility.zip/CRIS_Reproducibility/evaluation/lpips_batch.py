"""Compute calibrated LPIPS scores for image pairs listed in a CSV file."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import lpips
import torch
from PIL import Image
from torchvision.transforms.functional import pil_to_tensor


def load_image(path: str) -> tuple[torch.Tensor, tuple[int, int]]:
    """Load an RGB or grayscale image without changing its resolution."""
    with Image.open(path) as source:
        original_size = source.size
        if source.mode == "RGB":
            tensor = pil_to_tensor(source).float()
        elif source.mode in ("L", "I;16", "I", "F"):
            if source.mode != "L":
                source = source.convert("L")
            tensor = pil_to_tensor(source).float().repeat(3, 1, 1)
        else:
            raise ValueError(
                f"Expected an RGB or grayscale image, got {source.mode}: {path}"
            )
    tensor = tensor.unsqueeze(0) / 255.0
    return tensor * 2.0 - 1.0, original_size


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--net", default="alex", choices=("alex", "vgg", "squeeze"))
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = lpips.LPIPS(net=args.net, version="0.1").to(device).eval()
    rows: list[dict[str, str]] = []

    with Path(args.manifest).open("r", newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        for row in reader:
            reference, reference_size = load_image(row["Reference"])
            candidate, candidate_size = load_image(row["Candidate"])
            if reference_size != candidate_size:
                raise ValueError(
                    "LPIPS image-pair resolution mismatch: "
                    f"{row['Reference']}={reference_size}, "
                    f"{row['Candidate']}={candidate_size}"
                )
            reference = reference.to(device)
            candidate = candidate.to(device)
            with torch.no_grad():
                score = float(model(reference, candidate).item())
            row["LPIPS"] = f"{score:.10f}"
            rows.append(row)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=[*rows[0].keys()])
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
