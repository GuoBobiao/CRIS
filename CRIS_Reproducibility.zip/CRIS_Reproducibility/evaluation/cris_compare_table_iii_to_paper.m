function comparison = cris_compare_table_iii_to_paper(summary, catalog)
% Compare a full 60-image run with the values rounded in the manuscript.

published = cris_published_table_iii();
variantColumn = strings(0, 1);
rowColumn = strings(0, 1);
metricColumn = strings(0, 1);
reproducedColumn = zeros(0, 1);
publishedColumn = zeros(0, 1);

for variantIndex = 1:numel(published.variants)
    variant = published.variants(variantIndex);
    leftName = sprintf('%s_RobustnessOrStego', variant);
    rightName = sprintf('%s_CredibilityOrTrustworthy', variant);

    append("Quality: PSNR stego", "PSNR-Stego", summary{1, leftName}, ...
        published.quality.PSNR(variantIndex, 1));
    append("Quality: PSNR trustworthy", "PSNR-Trustworthy", ...
        summary{1, rightName}, published.quality.PSNR(variantIndex, 2));
    append("Quality: LPIPS stego", "LPIPS-Stego", summary{2, leftName}, ...
        published.quality.LPIPS(variantIndex, 1));
    append("Quality: LPIPS trustworthy", "LPIPS-Trustworthy", ...
        summary{2, rightName}, published.quality.LPIPS(variantIndex, 2));

    for attackIndex = 1:height(catalog)
        summaryRow = attackIndex + 2;
        append(catalog.Label(attackIndex), "Robustness", ...
            summary{summaryRow, leftName}, ...
            published.robustness(attackIndex, variantIndex));
        append(catalog.Label(attackIndex), "Credibility", ...
            summary{summaryRow, rightName}, ...
            published.credibility(attackIndex, variantIndex));
    end
end

absoluteError = abs(reproducedColumn - publishedColumn);
comparison = table(variantColumn, rowColumn, metricColumn, ...
    reproducedColumn, publishedColumn, absoluteError, ...
    'VariableNames', {'Variant', 'Entry', 'Metric', 'Reproduced', ...
    'Published', 'AbsoluteError'});

    function append(rowLabel, metricLabel, reproduced, expected)
        variantColumn(end + 1, 1) = variant;
        rowColumn(end + 1, 1) = rowLabel;
        metricColumn(end + 1, 1) = metricLabel;
        reproducedColumn(end + 1, 1) = reproduced;
        publishedColumn(end + 1, 1) = expected;
    end
end
