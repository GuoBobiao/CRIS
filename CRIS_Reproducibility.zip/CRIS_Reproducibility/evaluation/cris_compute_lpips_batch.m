function scores = cris_compute_lpips_batch(cfg, manifestPath, outputPath)
% Run the pinned Python LPIPS evaluator and return one score per manifest row.

script = fullfile(cfg.projectRoot, "evaluation", "lpips_batch.py");
python = string(cfg.evaluation.lpips.pythonExecutable);
probe = sprintf('"%s" -c "import torch,lpips,PIL"', python);
[probeStatus, ~] = system(probe);
if probeStatus ~= 0
    warning('CRIS:LPIPSUnavailable', ...
        ['LPIPS was not computed because the configured Python environment ' ...
         'does not contain torch, lpips, and Pillow. See requirements/.']);
    scores = nan(0, 1);
    return;
end

command = sprintf('"%s" "%s" --manifest "%s" --output "%s" --net %s', ...
    python, script, manifestPath, outputPath, cfg.evaluation.lpips.network);
[status, commandOutput] = system(command);
if status ~= 0
    warning('CRIS:LPIPSFailed', 'LPIPS failed: %s', commandOutput);
    scores = nan(0, 1);
    return;
end

tableOutput = readtable(outputPath, "TextType", "string");
scores = tableOutput.LPIPS;
end
