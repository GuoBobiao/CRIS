"""Compute the LPIPS row of the principal quality table from supplied images.

Images are evaluated at their original spatial resolution. RGB inputs are kept
unchanged, while single-channel grayscale inputs are replicated to three
identical channels for the pretrained LPIPS network.

This script reads the existing cover, stego, and trustworthy images. It does
not rerun CRIS embedding or extraction. The saved secret files are not needed
for this image-quality calculation. No input or output path is inferred from
the script location; both paths must be supplied explicitly at runtime.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path
from typing import Any


SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
VARIANT_LAYOUT = {
    "PCET": ("CRIS-PCET", "Image"),
    "PCT": ("CRIS-PCT", "Image"),
    "PST": ("CRIS-PST", "image"),
}
FOUR_DECIMAL_PLACES = Decimal("0.0001")
TABLE_III_LPIPS_VERSION = "0.1"
EXPECTED_PACKAGE_VERSIONS = {
    "lpips": "0.1.4",
    "torch": "2.1.2",
    "torchvision": "0.16.2",
    "Pillow": "10.2.0",
}
# These manuscript values are used only for comparison, never for computation.
PUBLISHED_TABLE_III_LPIPS = {
    "PCET": (Decimal("0.0467"), Decimal("0.0742")),
    "PCT": (Decimal("0.0210"), Decimal("0.0532")),
    "PST": (Decimal("0.0262"), Decimal("0.0575")),
}


@dataclass(frozen=True)
class ImagePair:
    variant: str
    image_index: int
    cover_name: str
    kind: str
    reference: Path
    candidate: Path


def parse_arguments() -> argparse.Namespace:
    """Parse command-line options without importing the LPIPS environment."""
    parser = argparse.ArgumentParser(
        description="Compute the principal-table LPIPS row for CRIS.",
        epilog=(
            "Example: python main_table_iii_lpips.py --data-root "
            '"/path/to/data" --output-dir "/path/to/results"'
        ),
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        required=True,
        help=(
            "User-specified dataset root containing Cover_Image, CRIS-PCET, "
            "CRIS-PCT, and CRIS-PST."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        required=True,
        help="User-specified directory for the LPIPS result files.",
    )
    parser.add_argument(
        "--net",
        choices=("alex", "vgg", "squeeze"),
        default="alex",
        help="LPIPS backbone. The manuscript uses calibrated AlexNet.",
    )
    parser.add_argument(
        "--device",
        choices=("auto", "cpu", "cuda"),
        default="auto",
        help="Inference device. Auto selects CUDA when available.",
    )
    parser.add_argument(
        "--max-images",
        type=int,
        default=None,
        help="Optional positive image limit for a smoke test.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate and count image pairs without loading the LPIPS model.",
    )
    args = parser.parse_args()
    if args.max_images is not None and args.max_images <= 0:
        parser.error("--max-images must be a positive integer")
    return args


def list_images(directory: Path) -> list[Path]:
    """Return supported images in stable case-insensitive filename order."""
    if not directory.is_dir():
        raise FileNotFoundError(f"Image directory does not exist: {directory}")
    files = [
        path
        for path in directory.iterdir()
        if path.is_file() and path.suffix.lower() in SUPPORTED_EXTENSIONS
    ]
    files.sort(key=lambda path: path.name.casefold())
    if not files:
        raise FileNotFoundError(f"No supported images were found in {directory}")
    return files


def index_by_stem(files: list[Path], directory: Path) -> dict[str, Path]:
    """Build an unambiguous case-insensitive stem-to-path index."""
    index: dict[str, Path] = {}
    for path in files:
        key = path.stem.casefold()
        if key in index:
            raise ValueError(f"Duplicate image stem '{path.stem}' in {directory}")
        index[key] = path
    return index


def match_image(index: dict[str, Path], cover: Path, directory: Path) -> Path:
    """Match a candidate image to one cover by filename stem."""
    key = cover.stem.casefold()
    if key not in index:
        raise FileNotFoundError(
            f"No image in {directory} matches cover '{cover.name}'"
        )
    return index[key]


def build_pairs(data_root: Path, max_images: int | None) -> list[ImagePair]:
    """Create all principal-table cover/stego/trustworthy pairs."""
    covers = list_images(data_root / "Cover_Image")
    if max_images is not None:
        covers = covers[:max_images]

    pairs: list[ImagePair] = []
    for variant, (variant_folder, image_folder) in VARIANT_LAYOUT.items():
        variant_root = data_root / variant_folder
        stego_directory = variant_root / "Stego_Image"
        trustworthy_directory = (
            variant_root / image_folder / "Trustworthy_Image"
        )
        stego_index = index_by_stem(list_images(stego_directory), stego_directory)
        trustworthy_index = index_by_stem(
            list_images(trustworthy_directory), trustworthy_directory
        )
        for image_index, cover in enumerate(covers, start=1):
            pairs.append(
                ImagePair(
                    variant,
                    image_index,
                    cover.name,
                    "Stego",
                    cover,
                    match_image(stego_index, cover, stego_directory),
                )
            )
            pairs.append(
                ImagePair(
                    variant,
                    image_index,
                    cover.name,
                    "Trustworthy",
                    cover,
                    match_image(trustworthy_index, cover, trustworthy_directory),
                )
            )
    return pairs


def import_lpips_environment() -> tuple[Any, Any, Any, Any]:
    """Import pinned runtime dependencies and provide a useful failure message."""
    try:
        import lpips
        import torch
        from PIL import Image
        from torchvision.transforms.functional import pil_to_tensor
    except ModuleNotFoundError as error:
        raise SystemExit(
            "Missing LPIPS dependency. Create the pinned environment with:\n"
            "  conda env create -f requirements/environment-lpips.yml\n"
            "  conda activate cris-lpips\n"
            "Then rerun: python main_table_iii_lpips.py"
        ) from error
    return lpips, torch, Image, pil_to_tensor


def load_lpips_tensor(
    path: Path, device: Any, torch: Any, Image: Any, pil_to_tensor: Any
) -> Any:
    """Load an RGB or grayscale image without changing its resolution."""
    with Image.open(path) as source:
        original_size = source.size
        if source.mode == "RGB":
            tensor = pil_to_tensor(source).to(dtype=torch.float32)
        elif source.mode in ("L", "I;16", "I", "F"):
            if source.mode != "L":
                source = source.convert("L")
            tensor = pil_to_tensor(source).to(dtype=torch.float32)
            tensor = tensor.repeat(3, 1, 1)
        else:
            raise ValueError(
                f"Expected an RGB or grayscale image, but got mode "
                f"'{source.mode}' from {path}"
            )

    tensor = tensor.unsqueeze(0)  # [1,3,H,W]
    tensor = (tensor / 127.5 - 1.0).to(device)  # [0,255] -> [-1,1]
    return tensor, original_size


def select_device(requested: str, torch: Any) -> Any:
    """Resolve the requested device and reject unavailable CUDA explicitly."""
    if requested == "auto":
        requested = "cuda" if torch.cuda.is_available() else "cpu"
    if requested == "cuda" and not torch.cuda.is_available():
        raise SystemExit("CUDA was requested, but torch.cuda.is_available() is false.")
    return torch.device(requested)


def compute_scores(
    pairs: list[ImagePair], net: str, requested_device: str
) -> tuple[list[dict[str, object]], dict[str, object]]:
    """Compute one calibrated LPIPS score for every manifest pair."""
    lpips, torch, Image, pil_to_tensor = import_lpips_environment()
    device = select_device(requested_device, torch)
    installed_versions = get_installed_versions()
    report_version_differences(installed_versions)
    print(
        "LPIPS protocol: native resolution, no resize, RGB unchanged, "
        "grayscale replicated 1->3, [-1,1], "
        f"backbone={net}, version={TABLE_III_LPIPS_VERSION}, device={device}"
    )
    model = lpips.LPIPS(
        net=net, version=TABLE_III_LPIPS_VERSION
    ).to(device).eval()
    rows: list[dict[str, object]] = []

    for pair_index, pair in enumerate(pairs, start=1):
        reference, reference_size = load_lpips_tensor(
            pair.reference, device, torch, Image, pil_to_tensor
        )
        candidate, candidate_size = load_lpips_tensor(
            pair.candidate, device, torch, Image, pil_to_tensor
        )
        if reference_size != candidate_size:
            raise ValueError(
                f"Resolution mismatch for '{pair.cover_name}' ({pair.variant}, "
                f"{pair.kind}): reference={reference_size}, "
                f"candidate={candidate_size}. No resizing is performed."
            )

        with torch.no_grad():
            score = float(model(reference, candidate).item())
        rows.append(
            {
                "Variant": pair.variant,
                "ImageIndex": pair.image_index,
                "CoverName": pair.cover_name,
                "Kind": pair.kind,
                "Reference": str(pair.reference.resolve()),
                "Candidate": str(pair.candidate.resolve()),
                "LPIPS": score,
            }
        )
        print(
            f"[{pair_index:>3}/{len(pairs)}] "
            f"{pair.variant} {pair.kind:<11} {pair.cover_name} "
            f"[{reference_size[0]}x{reference_size[1]}]: "
            f"{format_four(score)}"
        )
    runtime = {
        "device": str(device),
        "package_versions": installed_versions,
    }
    return rows, runtime


def get_installed_versions() -> dict[str, str]:
    """Return versions of packages that can affect LPIPS reproducibility."""
    versions: dict[str, str] = {}
    for package in EXPECTED_PACKAGE_VERSIONS:
        try:
            versions[package] = package_version(package)
        except PackageNotFoundError:
            versions[package] = "not installed"
    return versions


def report_version_differences(installed: dict[str, str]) -> None:
    """Warn when the active environment differs from the pinned environment."""
    for package, expected in EXPECTED_PACKAGE_VERSIONS.items():
        actual = installed[package]
        if actual != expected:
            print(
                f"WARNING: {package}={actual}; the pinned manuscript "
                f"environment uses {expected}."
            )


def summarize(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    """Average LPIPS by variant and calculate Trustworthy minus Stego."""
    summary: list[dict[str, object]] = []
    for variant in VARIANT_LAYOUT:
        stego = [
            float(row["LPIPS"])
            for row in rows
            if row["Variant"] == variant and row["Kind"] == "Stego"
        ]
        trustworthy = [
            float(row["LPIPS"])
            for row in rows
            if row["Variant"] == variant and row["Kind"] == "Trustworthy"
        ]
        if not stego or len(stego) != len(trustworthy):
            raise ValueError(f"Incomplete LPIPS pairs for {variant}")
        stego_mean = sum(stego) / len(stego)
        trustworthy_mean = sum(trustworthy) / len(trustworthy)
        summary.append(
            {
                "Variant": variant,
                "StegoLPIPS": stego_mean,
                "TrustworthyLPIPS": trustworthy_mean,
                "Difference": trustworthy_mean - stego_mean,
                "ImageCount": len(stego),
            }
        )
    return summary


def round_four(value: object) -> Decimal:
    """Round to four decimal places using the fifth digit and ROUND_HALF_UP."""
    return Decimal(str(value)).quantize(FOUR_DECIMAL_PLACES, rounding=ROUND_HALF_UP)


def format_four(value: object) -> str:
    """Return exactly four digits after the decimal point."""
    rounded = round_four(value)
    if rounded == 0:
        rounded = abs(rounded)
    return format(rounded, ".4f")


def make_table_iii_row(summary: list[dict[str, object]]) -> dict[str, object]:
    """Create the one-row, four-decimal manuscript layout."""
    by_variant = {str(row["Variant"]): row for row in summary}
    table_row: dict[str, object] = {"Metric": "LPIPS"}
    for variant in VARIANT_LAYOUT:
        row = by_variant[variant]
        stego = round_four(row["StegoLPIPS"])
        trustworthy = round_four(row["TrustworthyLPIPS"])
        table_row[f"{variant}_Robustness_Stego"] = format_four(stego)
        table_row[f"{variant}_Credibility_Trustworthy"] = format_four(
            trustworthy
        )
        table_row[f"{variant}_Difference"] = format_four(trustworthy - stego)
    return table_row


def format_summary_rows(
    summary: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Format aggregate LPIPS metrics for publication-facing CSV output."""
    formatted: list[dict[str, object]] = []
    for row in summary:
        stego = round_four(row["StegoLPIPS"])
        trustworthy = round_four(row["TrustworthyLPIPS"])
        formatted.append(
            {
                "Variant": row["Variant"],
                "StegoLPIPS": format_four(stego),
                "TrustworthyLPIPS": format_four(trustworthy),
                "Difference": format_four(trustworthy - stego),
                "ImageCount": row["ImageCount"],
            }
        )
    return formatted


def make_paper_comparison(
    summary: list[dict[str, object]],
) -> list[dict[str, object]]:
    """Compare computed aggregates with the paper without changing scores."""
    by_variant = {str(row["Variant"]): row for row in summary}
    comparison: list[dict[str, object]] = []
    for variant, (paper_stego, paper_trustworthy) in (
        PUBLISHED_TABLE_III_LPIPS.items()
    ):
        computed = by_variant[variant]
        computed_stego = round_four(computed["StegoLPIPS"])
        computed_trustworthy = round_four(computed["TrustworthyLPIPS"])
        comparison.append(
            {
                "Variant": variant,
                "ComputedStegoLPIPS": format_four(computed_stego),
                "PaperStegoLPIPS": format_four(paper_stego),
                "StegoDelta": format_four(computed_stego - paper_stego),
                "ComputedTrustworthyLPIPS": format_four(computed_trustworthy),
                "PaperTrustworthyLPIPS": format_four(paper_trustworthy),
                "TrustworthyDelta": format_four(
                    computed_trustworthy - paper_trustworthy
                ),
            }
        )
    return comparison


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    """Write dictionaries to UTF-8 CSV with a stable header."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def write_run_config(
    path: Path,
    args: argparse.Namespace,
    data_root: Path,
    output_dir: Path,
    pair_count: int,
    runtime: dict[str, object],
) -> None:
    """Save the complete LPIPS protocol and runtime environment as JSON."""
    config = {
        "data_root": str(data_root),
        "output_dir": str(output_dir),
        "pair_count": pair_count,
        "max_images": args.max_images,
        "preprocessing": {
            "color_mode": "RGB unchanged; grayscale replicated to 3 channels",
            "image_size": "native resolution",
            "interpolation": "none",
            "tensor_range": "[-1,1]",
        },
        "lpips": {
            "backbone": args.net,
            "version": TABLE_III_LPIPS_VERSION,
            "calibrated": True,
        },
        **runtime,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as stream:
        json.dump(config, stream, ensure_ascii=False, indent=2)


def print_summary(summary: list[dict[str, object]]) -> None:
    """Print the principal-table LPIPS row at four decimals."""
    print("\nPRINCIPAL TABLE - LPIPS (Difference = Trustworthy - Stego)")
    print("Variant   Stego/Robustness   Trustworthy/Credibility   Difference")
    for row in summary:
        stego = round_four(row["StegoLPIPS"])
        trustworthy = round_four(row["TrustworthyLPIPS"])
        print(
            f"{row['Variant']:<7}   {format_four(stego):>16}   "
            f"{format_four(trustworthy):>23}   "
            f"{format_four(trustworthy - stego):>10}"
        )


def main() -> int:
    """Run path validation, LPIPS inference, aggregation, and CSV export."""
    args = parse_arguments()
    data_root = args.data_root.expanduser().resolve()
    output_dir = args.output_dir.expanduser().resolve()
    pairs = build_pairs(data_root, args.max_images)
    print(f"Validated {len(pairs)} image pairs under {data_root}")
    if args.dry_run:
        print("Dry run completed; LPIPS inference was not started.")
        return 0

    rows, runtime = compute_scores(pairs, args.net, args.device)
    summary = summarize(rows)
    table_iii = [make_table_iii_row(summary)]
    summary_for_export = format_summary_rows(summary)
    paper_comparison = make_paper_comparison(summary)
    write_csv(output_dir / "Table_III_LPIPS_per_image.csv", rows)
    write_csv(output_dir / "Table_III_LPIPS_long.csv", summary_for_export)
    write_csv(output_dir / "Table_III_LPIPS.csv", table_iii)
    write_csv(
        output_dir / "Table_III_LPIPS_paper_comparison.csv", paper_comparison
    )
    write_run_config(
        output_dir / "Table_III_LPIPS_run_config.json",
        args,
        data_root,
        output_dir,
        len(pairs),
        runtime,
    )
    print_summary(summary)
    print(f"\nResults saved to: {output_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
