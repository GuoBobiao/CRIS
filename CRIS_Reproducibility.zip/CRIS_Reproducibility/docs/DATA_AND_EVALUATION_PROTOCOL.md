# Data and evaluation protocol

## Dataset and preprocessing

Table III and Fig. 8 use all 60 supplied CVG-UGR images. Each image is converted
to grayscale and resized to 1024x1024 before CRIS processing. Cover files are
sorted case-insensitively by filename. Secret file `j.xlsx` corresponds to the
`j`-th sorted cover file. The experiment code validates that every secret has
exactly 2048 binary values.

Attacked files are matched by cover stem. Both `anhinga.png` and historical
names such as `anhinga_stego.bmp` therefore map to the cover `anhinga.png`.
The code does not depend on the filesystem enumeration order of attack files.

## Batch embedding and extraction

`main_embed.m` processes the supported images in `Cover_Image` in stable,
case-insensitive filename order. For each cover it generates a 32x64 binary
secret image, whose 2048 pixels map one-to-one to the algorithm's 2048-bit
payload. The public entry point chooses a fresh Twister seed for every run.
The selected seed, secret-image dimensions, and complete run configuration are
exported, so the current run remains traceable. The actual binary secret images
are also saved losslessly as PNG for receiver-side accuracy evaluation.

The sender output stores same-stem secret, stego, and trustworthy PNG files plus
a CSV/XLSX manifest containing every input and output path. Transform plans are
prepared once per variant and reused for the entire batch; this improves speed
without changing any embedding decision.

`main_extract.m` reads the batch trustworthy-image folder and matches each
received image to its saved secret image by filename stem. The saved secret is
used only after blind receiver-side extraction to calculate bit accuracy; it is
never passed to `cris_extract_image`. For each image the driver exports the
extracted binary image, extracted bit vector, bit-error count, bit-error rate,
message accuracy, fingerprint credibility, and acceptance decision. It also
exports mean per-image accuracy and pooled accuracy across all extracted bits.

## Table III

The 17 folder aliases are declared in `cris_table_iii_catalog`. Historical
differences between PCET (`+`) and PCT/PST (`_`) sanitization folder names are
handled explicitly. JPEG, scaling, and sanitization outputs are read from the
supplied data rather than regenerated, which preserves the exact data evaluated
in the manuscript.

For every received image:

- robustness is the bit accuracy between the 2048-bit secret and the extracted
  message, as defined by Eq. (14);
- credibility is the mean of the eight block-pair fingerprint matching rates,
  as defined by Eq. (28);
- difference is `credibility - robustness`.

PSNR is computed in MATLAB between the cover and stego image and between the
cover and trustworthy image. LPIPS uses the calibrated AlexNet model from
`lpips==0.1.4`. Stored RGB images are retained unchanged, while grayscale
images are replicated from one channel to three channels. The original width
and height are preserved without resizing, and tensors are scaled to [-1,1].
LPIPS model version 0.1 and its learned calibration are used explicitly. The pinned environment is in
`requirements/environment-lpips.yml`. If this environment is unavailable,
LPIPS is exported as `NaN` with a warning. The pipeline never substitutes SSIM
or an uncalibrated feature distance while labeling it LPIPS.

The standalone `main_table_iii_psnr.m` and `main_table_iii_lpips.py` entries read
the existing image folders and never invoke embedding or extraction. For both
metrics, the quality-row Difference is `Trustworthy - Stego`. The published
four-decimal presentation subtracts the two four-decimal aggregate values. The
PSNR entry additionally exports a paper-comparison CSV so that a supplied-data
version mismatch cannot be hidden by hard-coded manuscript numbers.

A full 60-image run creates `Table_III_paper_comparison.csv`, which places every
reproduced number next to the rounded value printed in the manuscript.

## Fig. 8

Fig. 8 reads the unmodified images in each variant's `Trustworthy_Image`
directory and applies the following attacks:

- Gaussian noise: MATLAB `imnoise(I,"gaussian",0,variance)` with variances
  0.0005-0.0010;
- salt-and-pepper noise: MATLAB `imnoise(I,"salt & pepper",density)` with
  densities 0.0005-0.0010;
- cropping: a centered square whose side lengths equal the configured ratio of
  the image dimensions is set to zero, for ratios 0.1-0.6;
- rotation: MATLAB `imrotate(I,angle,"nearest","crop")` for angles
  30, 60, 90, 120, 150, and 180 degrees.

Every attacked image is resized back to 1024x1024 before extraction, matching
the historical experiment script. Noise is deterministic: each
variant/attack/image tuple receives a seed derived from the public base seed
20260816. This removes the nondeterminism of the earlier `parfor` script and
makes results independent of worker scheduling.

## Exported evidence

Each experiment writes:

- a summary CSV and XLSX workbook;
- a long-form per-image CSV and XLSX sheet;
- a MAT file containing the tables and attack catalog;
- the complete run configuration;
- for Fig. 8, a PNG and editable MATLAB FIG plot.

The per-image records include the actual input path so that any aggregate can
be audited back to its source image.

All publication-facing aggregate metrics are formatted to exactly four decimal
places. The fifth decimal digit determines rounding; ties are rounded half-up.
Full-precision per-image values and MAT tables remain available for auditing.
