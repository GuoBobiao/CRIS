# Paper-to-code alignment

This document maps the revised manuscript to the public implementation.

## Algorithm 1: Trustworthy image generation

| Manuscript stage | Equations | Public implementation |
|---|---:|---|
| Paired local PHT invariants | (15)-(17) | `cris_prepare_pht_plan`, `cris_compute_pht_moments` |
| BQIM-AS message modulation | (18)-(25) | `cris_embed_message_pair` |
| State-aware fingerprint | (26) | `cris_generate_state_fingerprint` |
| Spatially decoupled DCT backup | manuscript Section IV-C2 | `cris_prepare_dct_plan`, `cris_embed_backup_fingerprint` |
| End-to-end sender | Algorithm 1 | `cris_embed_image`, called by `main_embed.m` |

## Algorithm 2: credibility awareness and message extraction

| Manuscript stage | Equations | Public implementation |
|---|---:|---|
| Degraded fingerprint generation | (26) | `cris_generate_state_fingerprint` |
| Backup fingerprint extraction | (27) | `cris_extract_backup_fingerprint` |
| Pair and image credibility | (28) | `cris_extract_image` |
| Message extraction | Section IV-E | `cris_extract_message_pair` |
| End-to-end receiver | Algorithm 2 | `cris_extract_image`, called by `main_extract.m` |

The receiver implementation accepts only the received image and public method
parameters. It does not read the original message or the sender-side
fingerprint. Ground truth is loaded only by the experiment drivers after
extraction to compute Eq. (14).

## Variant parameters

| Parameter | PCET | PCT | PST |
|---|---:|---:|---:|
| PHT model identifier | 1 | 2 | 3 |
| Message maximum order | 23 | 27 | 28 |
| Fingerprint maximum order | 20 | 30 | 30 |
| Fingerprint start position in the stable-feature sequence | 200 | 265 | 250 |
| Message bits per block pair | 256 | 256 | 256 |
| Fingerprint bits per block pair | 50 | 50 | 50 |

Shared parameters are image size 1024x1024, grayscale conversion, 4x4 local
blocks, eight horizontal block pairs, message length 2048, minimum combined
PHT order 9, message normalization factor 4000, base BQIM-AS step 10, DCT
normalization factor 10, and DCT-QIM step 2000.

The final per-feature message steps are fixed integer vectors containing only
11 and 12. `cris_variant_config` stores these exact vectors, which correspond
to the offline rule `round(10*(2-column_accuracy))`. This removes any external
calibration-file dependency without changing a quantization step.
