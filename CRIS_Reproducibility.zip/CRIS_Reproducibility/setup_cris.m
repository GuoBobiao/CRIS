function projectRoot = setup_cris()
% Add the CRIS reproducibility package to the MATLAB search path.

projectRoot = fileparts(mfilename("fullpath"));
addpath(projectRoot);
addpath(fullfile(projectRoot, "config"));
addpath(fullfile(projectRoot, "core"));
addpath(fullfile(projectRoot, "evaluation"));
addpath(fullfile(projectRoot, "experiments"));
addpath(fullfile(projectRoot, "utilities"));
end

