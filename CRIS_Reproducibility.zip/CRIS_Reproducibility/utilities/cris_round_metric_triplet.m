function roundedTable = cris_round_metric_triplet( ...
    inputTable, leftVariable, rightVariable, differenceVariable, decimalPlaces)
% Round two aggregate metrics and derive their publication-facing difference.

arguments
    inputTable table
    leftVariable (1,1) string
    rightVariable (1,1) string
    differenceVariable (1,1) string
    decimalPlaces (1,1) double {mustBeInteger, mustBeNonnegative} = 4
end

roundedTable = inputTable;
left = round(inputTable.(leftVariable), decimalPlaces);
right = round(inputTable.(rightVariable), decimalPlaces);
difference = round(right - left, decimalPlaces);
left(left == 0) = 0;
right(right == 0) = 0;
difference(difference == 0) = 0;
roundedTable.(leftVariable) = left;
roundedTable.(rightVariable) = right;
roundedTable.(differenceVariable) = difference;
end
