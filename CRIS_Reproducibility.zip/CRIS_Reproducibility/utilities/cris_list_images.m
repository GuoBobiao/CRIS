function files = cris_list_images(directory)
% List supported image files in a stable case-insensitive order.

directory = string(directory);
if ~isfolder(directory)
    error("CRIS:MissingImageDirectory", ...
        "Image directory does not exist: %s", directory);
end

extensions = ["*.png", "*.jpg", "*.jpeg", "*.bmp", "*.tif", "*.tiff"];
files = struct([]);
for extension = extensions
    matches = dir(fullfile(directory, extension));
    files = [files; matches(:)]; %#ok<AGROW>
end

if isempty(files)
    error("CRIS:NoImages", "No supported images were found in %s.", directory);
end

[~, order] = sort(lower(string({files.name})));
files = files(order);
end

