function cris_save_run_config(cfg, destination)
% Save a machine-readable configuration snapshot for one experiment run.

snapshot = cfg;
save(destination, "snapshot");
end

