function path = cris_find_matching_image(files, coverName)
% Match an attacked image to a cover stem, including historical suffixes.

[~, coverStem] = fileparts(coverName);
coverStem = lower(string(coverStem));
names = lower(string({files.name}));
stems = strings(size(names));
for index = 1:numel(names)
    [~, stem] = fileparts(names(index));
    stems(index) = stem;
end

exact = find(stems == coverStem, 1, "first");
if isempty(exact)
    prefixed = find(startsWith(stems, coverStem + "_"), 1, "first");
else
    prefixed = exact;
end

if isempty(prefixed)
    error("CRIS:MissingMatchedImage", ...
        "No image in %s matches cover '%s'.", files(1).folder, coverName);
end
path = fullfile(files(prefixed).folder, files(prefixed).name);
end

