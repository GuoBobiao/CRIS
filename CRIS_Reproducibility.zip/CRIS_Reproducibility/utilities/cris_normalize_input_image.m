function image = cris_normalize_input_image(image, targetSize)
% Convert an input image to the grayscale uint8 protocol used in the paper.

if size(image, 3) > 1
    image = rgb2gray(image(:, :, 1:3));
end
image = im2uint8(image);
if ~isequal(size(image, 1), targetSize(1)) || ...
        ~isequal(size(image, 2), targetSize(2))
    image = imresize(image, targetSize);
end
end

