function accuracy = cris_bit_accuracy(reference, estimate)
% Return bit-level extraction accuracy as defined by Eq. (14).

reference = reference(:);
estimate = estimate(:);
if numel(reference) ~= numel(estimate)
    error("CRIS:AccuracyLengthMismatch", ...
        "Reference and estimated messages must have the same length.");
end
accuracy = mean(reference == estimate);
end

