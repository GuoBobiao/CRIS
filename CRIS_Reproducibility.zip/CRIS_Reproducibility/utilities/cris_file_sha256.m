function digest = cris_file_sha256(path)
% Compute a SHA-256 digest using Java available inside MATLAB.

stream = java.io.FileInputStream(java.io.File(char(path)));
cleanup = onCleanup(@() stream.close());
hasher = java.security.MessageDigest.getInstance("SHA-256");
buffer = zeros(1, 1024 * 1024, "int8");
while true
    count = stream.read(buffer, 0, numel(buffer));
    if count < 0
        break;
    end
    hasher.update(buffer(1:count));
end
bytes = typecast(hasher.digest(), "uint8");
digest = lower(join(compose("%02x", bytes), ""));
clear cleanup;
end

