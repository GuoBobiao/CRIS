function formatted = cris_format_metric_columns( ...
    inputTable, variableNames, decimalPlaces)
% Format selected numeric table variables with fixed decimal places.

arguments
    inputTable table
    variableNames (1,:) string
    decimalPlaces (1,1) double {mustBeInteger, mustBeNonnegative} = 4
end

formatted = inputTable;
formatSpec = "%." + string(decimalPlaces) + "f";
availableNames = string(inputTable.Properties.VariableNames);

for variableName = variableNames
    if ~ismember(variableName, availableNames)
        error("CRIS:MissingTableVariable", ...
            "Table variable '%s' does not exist.", variableName);
    end
    values = inputTable.(variableName);
    if ~isnumeric(values)
        error("CRIS:NonNumericMetricVariable", ...
            "Table variable '%s' must be numeric.", variableName);
    end
    rounded = round(values, decimalPlaces);
    rounded(rounded == 0) = 0;
    formatted.(variableName) = compose(formatSpec, rounded);
end
end
