function secret = cris_load_secret(path, expectedLength)
% Load and validate a binary secret message from XLSX, CSV, TXT, or MAT.

path = string(path);
if ~isfile(path)
    error("CRIS:MissingSecret", "Secret file does not exist: %s", path);
end
[~, ~, extension] = fileparts(path);

if strcmpi(extension, ".mat")
    data = load(path);
    names = fieldnames(data);
    if isempty(names)
        error("CRIS:EmptySecretMat", "The MAT file contains no variables.");
    end
    secret = data.(names{1});
else
    secret = readmatrix(path);
end

secret = double(secret(:).');
secret = secret(~isnan(secret));
if numel(secret) ~= expectedLength
    error("CRIS:InvalidSecretLength", ...
        "Expected %d secret bits in %s, but found %d.", ...
        expectedLength, path, numel(secret));
end
if any(secret ~= 0 & secret ~= 1)
    error("CRIS:NonBinarySecret", "Secret values must be zero or one.");
end
end

