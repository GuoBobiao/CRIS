function manifest = cris_build_data_manifest(cfg)
% Build a compact manifest of supplied inputs and their SHA-256 digests.

roots = [fullfile(cfg.dataRoot, "Cover_Image")];
for variantName = cfg.variants
    variant = cris_variant_config(variantName);
    variantRoot = fullfile(cfg.dataRoot, variant.dataDirectory);
    roots(end + 1) = fullfile(variantRoot, "secret"); %#ok<AGROW>
    roots(end + 1) = fullfile(variantRoot, variant.imageDirectory, ...
        "Trustworthy_Image"); %#ok<AGROW>
end

relativePath = strings(0, 1);
bytes = zeros(0, 1);
sha256 = strings(0, 1);
for root = roots
    files = dir(fullfile(root, "**", "*"));
    files = files(~[files.isdir]);
    for index = 1:numel(files)
        fullPath = fullfile(files(index).folder, files(index).name);
        relativePath(end + 1, 1) = erase(string(fullPath), ...
            string(cfg.dataRoot) + filesep); %#ok<AGROW>
        bytes(end + 1, 1) = files(index).bytes; %#ok<AGROW>
        sha256(end + 1, 1) = cris_file_sha256(fullPath); %#ok<AGROW>
    end
end
manifest = table(relativePath, bytes, sha256, ...
    'VariableNames', {'RelativePath', 'Bytes', 'SHA256'});
end
