function directory = cris_prepare_output_directory(directory, overwrite)
% Create an output directory and guard existing experiment artifacts.

directory = string(directory);
if ~isfolder(directory)
    mkdir(directory);
    return;
end

existing = dir(directory);
existing = existing(~ismember({existing.name}, {'.', '..'}));
if ~isempty(existing) && ~overwrite
    error('CRIS:OutputExists', ...
        ['Output directory is not empty: %s. Set ' ...
         'cfg.execution.overwrite=true or move the previous results.'], ...
        directory);
end
end
