function directory = cris_resolve_attack_directory(imageRoot, aliases)
% Resolve one principal-table folder while accepting historical names.

aliases = string(aliases);
for alias = aliases
    candidate = fullfile(imageRoot, alias);
    if isfolder(candidate)
        directory = candidate;
        return;
    end
end
error("CRIS:MissingAttackDirectory", ...
    "None of these attack folders exists below %s: %s", ...
    imageRoot, strjoin(aliases, ", "));
end
