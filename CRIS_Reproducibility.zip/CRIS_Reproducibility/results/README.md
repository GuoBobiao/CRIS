# Generated results

This directory is reserved for generated experiment outputs. Its contents are
excluded from version control so that a fresh release cannot be mistaken for a
completed experiment run.

- `batch/` is created by `main_embed.m` and `main_extract.m`.
- `table_iii/` is created by `reproduce_table_iii.m`.
- `table_iii_quality/` is created by the PSNR and LPIPS entry points.
- `fig8/` is created by `reproduce_fig8.m`.
