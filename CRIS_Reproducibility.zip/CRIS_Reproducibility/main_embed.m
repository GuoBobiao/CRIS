% Batch-embed random binary secret images into all cover images in a folder.

projectRoot = setup_cris();
cfg = cris_default_config(projectRoot);

% Select one of: "PCET", "PCT", or "PST".
cfg.variant = "PST";

% Configure the input folder and the random secret-image generator.
cfg.batch.coverDirectory = fullfile(cfg.dataRoot, "Cover_Image");
cfg.batch.secretImageSize = [32, 64];

% Create a new seed on every run. The seed and generated secret images are
% saved with the outputs, so extraction accuracy remains independently
% verifiable for the current run.
rng("shuffle");
cfg.execution.randomSeed = randi(2^31 - 1) - 1;

% Set to a positive integer for a quick smoke test; use Inf for all images.
cfg.execution.maxImages = Inf; % Inf

% Refresh the batch artifacts when this entry point is rerun.
% The lower-level API keeps overwrite protection disabled by default.
cfg.execution.overwrite = true;

result = cris_run_embedding_batch(cfg);
displaySummary = result.summary(:, ...
    ["Variant", "ImageCount", "RandomSeed", ...
     "MeanStegoPSNR", "MeanTrustworthyPSNR"]);
displaySummary = cris_format_metric_columns(displaySummary, ...
    ["MeanStegoPSNR", "MeanTrustworthyPSNR"], 4);
disp(displaySummary);
fprintf("Average robustness embedding time (cover to stego): " + ...
    "%.4f seconds/image (%d images).\n", ...
    result.summary.MeanRobustnessEmbeddingTimeSeconds, ...
    result.summary.ImageCount);
fprintf("Average credibility embedding time (stego to trustworthy): " + ...
    "%.4f seconds/image (%d images).\n", ...
    result.summary.MeanCredibilityEmbeddingTimeSeconds, ...
    result.summary.ImageCount);
